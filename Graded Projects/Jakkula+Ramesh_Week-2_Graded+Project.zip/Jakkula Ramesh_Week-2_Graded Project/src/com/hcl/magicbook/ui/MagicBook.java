package com.hcl.magicbook.ui;

import java.util.List;
import java.util.Scanner;

import com.hcl.exception.BookNotFoundException;
import com.hcl.exception.UserNotFoundException;
import com.hcl.magicbook.dao.BookDAOImp;
import com.hcl.magicbook.dao.IBookDAO;
import com.hcl.magicbook.dao.IuserDAO;

import com.hcl.magicbook.dao.UserDAOImp;
import com.hcl.magicbook.pojo.Book;
import com.hcl.magicbook.pojo.User;
import com.hcl.service.LogService;

public class MagicBook {
	IuserDAO dao = new UserDAOImp();

	public static final LogService LOGGER = new LogService();

	public static void main(String[] args) {
		Runnable r = new MythreadRunnable();
		Thread t = new Thread(r);
		t.start();
		Scanner scanner = new Scanner(System.in);

		System.out.println("**** Welcome to MagicBook **** ");
		System.out.println("login here");
		LOGGER.log(" Taking input from user ");
		System.out.println("enter username");
		String username = scanner.nextLine();
		System.out.println(" enter password");
		String password = scanner.nextLine();
		MagicBook mb = new MagicBook();

		boolean isuservalid = mb.validateUserLogin(username, password);
		if (isuservalid) {

			System.out.println("Book menu");
			getBookMenu();
		} else {
			try {
				throw new UserNotFoundException();
			} catch (UserNotFoundException e) {
				System.err.println(" Sorry,Invalid User Credentials " + e);
				LOGGER.log(" User NotException Details ");
			}
		}
	}

	public boolean validateUserLogin(String username, String password) {
		boolean isExist = false;
		List<User> users = dao.getAllUser();
		LOGGER.log(" Verifying User Details ");
		for (User us : users) {
			if (us.getUserName().equals(username) && us.getPassword().equals(password)) {
				isExist = true;
			}
		}
		return isExist;
	}

	public static void getBookMenu() {
		LOGGER.log(" Book Menu ");
		System.out.println("**** WELCOME TO BOOK MENU ****");
		boolean flag = true;
		IBookDAO bookdao = new BookDAOImp();
		while (flag) {
			System.out.println("1. New Books");
			System.out.println("2. fav Books");
			System.out.println("3.completed Books");
			System.out.println("0 Exist");
			Scanner sc = new Scanner(System.in);
			int choice = sc.nextInt();
			switch (choice) {
			case 1:
				LOGGER.log(" New Book Menu ");
				List<Book> newBooks = bookdao.getAllBooks();
				System.out.println("i.show all new books");

				System.out.println("ii. get book by id");
				String key = sc.next();
				boolean b = false;
				switch (key) {
				case "i":
					for (Book book : newBooks) {
						System.out.println(book);
					}
					break;
				case "ii":
					System.out.println("Enter Book Id");
					int id = sc.nextInt();
					for (Book book : newBooks) {
						if (book.getBookId() == id) {

							System.out.println(book);
							b = true;
						}

					}
					if (b == false)
						try {
							throw new BookNotFoundException();
						} catch (BookNotFoundException e) {
							System.err.println(" Sorry,Book Not Available " + e);
						}
					break;
				default:
					System.out.println("wrong choice");
					break;
				}

				break;
			case 2:
				LOGGER.log(" Favourite Book Menu");
				List<Book> favbook = bookdao.getAllFavBooks();
				System.out.println("i.show all new books");
				System.out.println("ii. get book by id");
				String key1 = sc.next();
				boolean b1 = false;
				switch (key1) {
				case "i":
					for (Book book : favbook) {
						System.out.println(book);
					}
					break;
				case "ii":
					System.out.println("Enter Book Id");
					int id = sc.nextInt();
					for (Book book : favbook) {
						if (book.getBookId() == id) {
							System.out.println(book);
							b1 = true;
						}
					}
					if (b1 == false)
						try {
							throw new BookNotFoundException();
						} catch (BookNotFoundException e) {
							System.err.println(" Sorry,Book Not Available " + e);
						}
					break;
				default:
					System.out.println("wrong choice");
					break;
				}

				break;
			case 3:
				LOGGER.log("Completed Book Menu");
				List<Book> completedbook = bookdao.getAllCompletedBooks();
				System.out.println("i.show all new books");
				System.out.println("ii. get book by id");
				String key2 = sc.next();
				boolean b2 = false;
				switch (key2) {
				case "i":
					for (Book book : completedbook) {
						System.out.println(book);
					}
					break;
				case "ii":
					System.out.println("Enter Book Id");
					int id = sc.nextInt();
					for (Book book : completedbook) {
						if (book.getBookId() == id) {
							System.out.println(book);
							b2 = true;
						}
					}
					if (b2 == false)
						try {
							throw new BookNotFoundException();
						} catch (BookNotFoundException e) {
							System.err.println(" Sorry,Book Not Available " + e);
						}
					break;
				default:
					System.out.println("wrong choice");
					break;
				}

				break;
			default:
				System.out.println("wrong choice and visit agin");
				break;

			}
		}
	}
}
