package com.hcl.messege;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MessegeApplication {

	public static void main(String[] args) {
		SpringApplication.run(MessegeApplication.class, args);
	}

}
