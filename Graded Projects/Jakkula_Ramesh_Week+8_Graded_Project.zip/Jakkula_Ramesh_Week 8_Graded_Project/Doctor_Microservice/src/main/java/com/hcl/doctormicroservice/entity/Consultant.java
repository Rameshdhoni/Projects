package com.hcl.doctormicroservice.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
/*
 * @Author: Ramesh
 * Date: 23-12-2022
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "Consultant_Table")
public class Consultant {
	@Id
	@NotNull
	private long consultantId;
	@Positive // consulatntFee should be positive values
	private long consulatntFee;
	@NotNull
	private long doctorId;
}
