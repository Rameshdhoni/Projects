package com.hcl.gradedproject6.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.hcl.gradedproject6.entities.Admin;
import com.hcl.gradedproject6.entities.Book;
import com.hcl.gradedproject6.entities.FavouriteBook;
import com.hcl.gradedproject6.entities.User;
import com.hcl.gradedproject6.repositories.BookRepository;
import com.hcl.gradedproject6.repositories.FavouriteBookRepository;
import com.hcl.gradedproject6.repositories.UserRepository;

@Service
public class IUserServiceImp implements IUserService {
	@Autowired
	UserRepository repos;
	@Autowired
	BookRepository repo;
	@Autowired
	FavouriteBookRepository favRepo;

	@Override
	public Book searchBookById(int bookId) {

		return repo.findById(bookId).orElse(null);
	}

	@Override
	public Book searchBookByAuthourName(String authourName) {

		return repo.searchBookByAuthourName(authourName);
	}

	@Override
	public Book searchBookByBookName(String bookName) {

		return repo.searchBookByBookName(bookName);
	}

	@Override
	public Book searchBookByPublicationName(String publicationName) {

		return repo.searchBookByPublicationName(publicationName);
	}

	@Override
	public List<Book> getAllBook() {
		return repo.findAll();
	}

	@Override
	public List<Book> searchBookByPriceRange(int low, int high) {
		// TODO Auto-generated method stub
		return repo.searchBookByPriceRange(low, high);
	}

	@Override
	public List<Book> sortBookByPrice() {
		// TODO Auto-generated method stub
		return repo.sortBookByPrice();
	}

	@Override
	public User addUser(User user) {
		// TODO Auto-generated method stub
		return repos.save(user);
	}

	@Override
	public User findByuname(String uname) {
		// TODO Auto-generated method stub
		return repos.findByuname(uname);
	}

	@Override
	public ResponseEntity<String> registerUser(User user) {
		ResponseEntity<String> response = null;
		  User use = repos.save(user); 
		  if
		  (use != null) {
			  response = new  ResponseEntity<String>("user registration done", HttpStatus.ACCEPTED); }
		  else { 
			  response = new ResponseEntity<String>("user registration Failed", HttpStatus.NOT_ACCEPTABLE);
			  } 
		  return response; 
		  }

	@Override
	public FavouriteBook addFavouriteBook(FavouriteBook book) {
		// TODO Auto-generated method stub
		return favRepo.save(book);
	}
	}


