package com.hcl.mp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Scanner;
import java.util.function.Supplier;

import com.hcl.mp.db.*;
import com.hcl.mp.pojo.FoodItem;
import com.hcl.mp.pojo.NonVegItem;
import com.hcl.mp.pojo.VegItem;
import com.hcl.mp.ui.LogService;

public class MenuDAOImpl implements MenuDAO {
	public static final LogService LOGGER = new LogService();
	public static int customerBill = 0;

	List<Integer> orderedItemsIdsList = new ArrayList<>();;

	private Connection a;
//singleton pattern used
	public MenuDAOImpl() {
		a = DBConnection.getConnection();
	}
	public static MenuDAO getMenuDAOImpl() {
		
		 MenuDAO MenuDAOImpl = null;
		if (MenuDAOImpl == null) {
			MenuDAOImpl = new MenuDAOImpl();

		}
		return MenuDAOImpl;
	}
	
	public void displayItems() {
		try {

			Connection a = DBConnection.getConnection();
			Connection a1 = DBConnection.getConnection();

			// Step#3. Write SQL queries
			String sql = "SELECT * FROM food_items where category = ?";

			// Step#4. Get a connection
			PreparedStatement ps1 = a.prepareStatement(sql);

			PreparedStatement ps2 = a1.prepareStatement(sql);
			// ps.setInt(1, productId);
			ps2.setString(1, "Veg");
			ps1.setString(1, "Non-Veg");

			// Step#5. Execute the queries
			ResultSet result2 = ps2.executeQuery();
			ResultSet result1 = ps1.executeQuery();

			System.out.println("Non-Veg Items");
			System.out.println();
			while (result1.next()) {

				int id1 = result1.getInt("id");
				String name1 = result1.getString("item_name");
				int price1 = result1.getInt("price");
				String category1 = result1.getString("category");

				FoodItem item1 = new FoodItem(id1, name1, price1);
				NonVegItem nv = new NonVegItem(item1);

				System.out.println(nv);
			}
			System.out.println();
			System.out.println("Veg Items");
			System.out.println();
			while (result2.next()) {

				int id = result2.getInt("id");
				String name = result2.getString("item_name");
				int price = result2.getInt("price");
				String category = result2.getString("category");

				FoodItem item = new FoodItem(id, name, price);
				VegItem v = new VegItem(category, price, category, item);
				System.out.println(v);
			}

			// Step#6. Close the resources
			//ps1.close();
			//ps2.close();
			//a.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		System.out.println("\n");
		
		
	}

	@Override
	public void addFoodItems(FoodItem item, String category) {
		LOGGER.log(" add food items method started ");
		// TODO Auto-generated method stub
		try {

			Connection a = DBConnection.getConnection();

			// Step#3. Write SQL queries
			String s = "INSERT INTO food_items(item_name , price , category) VALUES(? , ? , ?)";

			// Step#4. Get a carrier
			PreparedStatement ps = a.prepareStatement(s);
			ps.setString(1, item.getItemName());
			ps.setInt(2, item.getPrice());
			ps.setString(3, category);

			// Step#5. Execute the queries
			ps.executeUpdate();
			// Step#6. Close the resources
			//ps.close();
			//a.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		showFoodItems();
		System.out.println();

	}

	@Override
	public void deleteFoodItems(int id) {
		// TODO Auto-generated method stub
		LOGGER.log(" deletedfood execution started ");
		try {

			Connection a = DBConnection.getConnection();

			// Step#3. Write SQL queries
			String s = "DELETE FROM food_items WHERE id = ?";

			// Step#4. Get a carrier
			PreparedStatement ps = a.prepareStatement(s);

			ps.setInt(1, id);

			// Step#5. Execute the queries
			ps.executeUpdate();
			// Step#6. Close the resources

			System.out.println("Food_Item whose id : " + id + " is DELETED Successsfully");
			//ps.close();
			//a.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		System.out.println();
	}

	@Override
	public void updateFoodItems(String name, int id, int price) {
		// TODO Auto-generated method stub
		LOGGER.log(" updatefood execution started ");
		try {

			Connection a = DBConnection.getConnection();

			// Step#3. Write SQL queries
			if (Objects.nonNull(name) && id == 0) {

				String sql = "UPDATE food_items SET price = ? WHERE item_name = ?";
				PreparedStatement ps = a.prepareStatement(sql);

				ps.setInt(1, price);
				ps.setString(2, name);
				ps.executeUpdate();
				System.out.println("Food_Item whose id : " + id + " is UPDATED Successsfully");
				ps.close();
			} else if (Objects.isNull(name) && id != 0) {

				String sql = "UPDATE food_items SET price = ? WHERE id = ?";
				PreparedStatement ps = a.prepareStatement(sql);

				ps.setInt(1, price);
				ps.setInt(2, id);
				ps.executeUpdate();
				System.out.println("Food_Item whose name : " + name + " is UPDATED Successsfully");

				//ps.close();

			}

			showFoodItems();

			//a.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		

	}

	@Override
	public void showFoodItems() {
		// TODO Auto-generated method stub
		try {

			Connection a = DBConnection.getConnection();
			Connection a1 = DBConnection.getConnection();

			// Step#3. Write SQL queries
			String sql = "SELECT * FROM food_items where category = ?";

			// Step#4. Get a carrier
			PreparedStatement ps1 = a.prepareStatement(sql);

			PreparedStatement ps2 = a1.prepareStatement(sql);
			// ps.setInt(1, productId);
			ps2.setString(1, "Veg");
			ps1.setString(1, "Non-Veg");

			// Step#5. Execute the queries
			ResultSet result2 = ps2.executeQuery();
			ResultSet result1 = ps1.executeQuery();

			System.out.println("Non-Veg Items");
			System.out.println();
			while (result1.next()) {

				int id1 = result1.getInt("id");
				String name1 = result1.getString("item_name");
				int price1 = result1.getInt("price");
				String category1 = result1.getString("category");

				FoodItem item1 = new FoodItem(id1, name1, price1);
				NonVegItem nv = new NonVegItem(item1);

				System.out.println(nv);
			}
			System.out.println();
			System.out.println("Veg Items");
			System.out.println();
			while (result2.next()) {

				int id = result2.getInt("id");
				String name = result2.getString("item_name");
				int price = result2.getInt("price");
				String category = result2.getString("category");

				FoodItem item = new FoodItem(id, name, price);
				VegItem v = new VegItem(category, price, category, item);
				System.out.println(v);
			}

			// Step#6. Close the resources
			//ps1.close();
			//ps2.close();
			//a.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		System.out.println("\n");
		

	}

	@Override
	public void billsGeneratedToday() {
		// TODO Auto-generated method stub
		int bill = MenuDAOImpl.customerBill;
		System.out.println("today total amount :  " + bill);
	}

	@Override
	public void totalSale() {
		// TODO Auto-generated method stub
		System.out.println("today total sale : 600 ");
	}

	@Override
	public void orderItems() {
		// TODO Auto-generated method stub
		Map<Integer, Integer> orderPerPlate = yourOrder();
		for(int key : orderPerPlate.keySet()) {
			int value = orderPerPlate.get(key);
			System.out.println(key+" : "+ value);
			
			
			userFinalBill(key , value);
		}
	}

	@Override
	public void userFinalBill(int key, int noOfPlates) {
		// TODO Auto-generated method stuby
		try {


			Connection a = DBConnection.getConnection();

			// Step#3. Write SQL queries
			String sql = "SELECT price FROM food_items WHERE id = ?";

			// Step#4. Get a carrier
			PreparedStatement ps = a.prepareStatement(sql);
			ps.setInt(1, key);

			// Step#5. Execute the queries
			ResultSet result = ps.executeQuery();
			while (result.next()) {
				int bill = result.getInt("price");
				customerBill = customerBill + (noOfPlates * bill);
				// System.out.println("Total Bill : " + customerBill);

			}

			// Step#6. Close the resources
			//ps.close();
			//a.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println();

	}
	private Map<Integer, Integer> yourOrder() {
		Supplier<Map<Integer, Integer>> mapOfOrdersPerPlates = () -> {

			Map<Integer, Integer> mapofOrder = new LinkedHashMap<>();
			System.out.println("order!!");
			while (true) {
				showFoodItems();
				System.out.println();
				Scanner sc = new Scanner(System.in);

				System.out.println("Enter any 2 Digit Number To ORDER (Ex :- 60) : \n Enter 0 to EXIT ");
				int option = sc.nextInt();

				if (10 <= option && option <= 99) {
					System.out.println("Enter Your Food-Item ID to Order : ");
					int id = sc.nextInt();
					System.out.println("How many PLATES do you want : ");
					int plates = sc.nextInt();

					mapofOrder.put(id, plates);
				} else if (option == 0) {
					System.out.println("Thank you for your Order");
					break;
				}

			}
			return mapofOrder;
		};
		return mapOfOrdersPerPlates.get();
	}


	@Override
	public void emptyBill() {
		// TODO Auto-generated method stub
		customerBill = 0;

	}

	

}
