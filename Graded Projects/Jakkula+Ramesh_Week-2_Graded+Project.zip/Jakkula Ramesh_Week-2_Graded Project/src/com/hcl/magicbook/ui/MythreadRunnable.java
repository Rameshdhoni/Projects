package com.hcl.magicbook.ui;

import com.hcl.service.LogService;

public class MythreadRunnable implements Runnable{
	public static final LogService LOGGER = new LogService();

	@Override
	public void run() {
		LOGGER.log(" Main method & Thread execution started ");
		
	}

}
