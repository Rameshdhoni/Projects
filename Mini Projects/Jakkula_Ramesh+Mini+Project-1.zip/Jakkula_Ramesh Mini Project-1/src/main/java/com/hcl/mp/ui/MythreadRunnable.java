package com.hcl.mp.ui;

public class MythreadRunnable implements Runnable {
	public static final LogService LOGGER = new LogService();

	@Override
	public void run() {
		LOGGER.log(" Main method & Thread execution started ");

	}

}
