package com.hcl.gradedproject6.service;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.hcl.gradedproject6.entities.Admin;
import com.hcl.gradedproject6.entities.Book;

@Service
public interface IAdminService {

	public Book insertBook(Book book);

	public Book updateBook(Book book);

	public String removeBook(int bookId);

	public Book searchBookById(int bookId);

	public Book searchBookByAuthourName(String authourName);

	public List<Book> getAllBook();

	public ResponseEntity<String> registerAdmin(Admin admin);

	public Admin findByaName(String aName);

}
