package com.hcl.doctormicroservice.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.doctormicroservice.dto.ConsultantDTO;
import com.hcl.doctormicroservice.entity.Consultant;
import com.hcl.doctormicroservice.repository.ConsultantRepository;
/*
 * @Author: Ramesh
 * Date: 23-12-2022
 */
@Service
public class ConsultantServiceImp implements IConsultantService {
	@Autowired
	ConsultantRepository repo;

	@Override
	// adding Consultant values
	public Consultant addConsultants(ConsultantDTO dto) {
		Consultant cons = new Consultant();
		cons.setConsultantId(dto.getConsultantId());
		cons.setConsulatntFee(dto.getConsulatntFee());
		cons.setDoctorId(dto.getDoctorId());
		return repo.save(cons);
	}

	@Override
	// Displaying Consultant details using id
	public Consultant getById(long id) {
		// TODO Auto-generated method stub
		return repo.findById(id).orElse(null);
	}

	@Override
	// Displaying all Consultant details
	public List<Consultant> getAll() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

}
