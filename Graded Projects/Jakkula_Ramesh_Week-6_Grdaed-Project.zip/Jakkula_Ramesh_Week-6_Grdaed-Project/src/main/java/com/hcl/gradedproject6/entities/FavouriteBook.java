package com.hcl.gradedproject6.entities;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;

@Entity
public class FavouriteBook {
	@Id
	private int bookId;
	private String bookName;
	private String authourName;
	private int bookPrice;
	private String publicationName;
	private int uid;

	public FavouriteBook() {
		super();
	}

	public FavouriteBook(int bookId, String bookName, String authourName, int bookPrice, String publicationName,
			int uid) {
		super();
		this.bookId = bookId;
		this.bookName = bookName;
		this.authourName = authourName;
		this.bookPrice = bookPrice;
		this.publicationName = publicationName;
		this.uid = uid;
	}

	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public String getAuthourName() {
		return authourName;
	}

	public void setAuthourName(String authourName) {
		this.authourName = authourName;
	}

	public int getBookPrice() {
		return bookPrice;
	}

	public void setBookPrice(int bookPrice) {
		this.bookPrice = bookPrice;
	}

	public String getPublicationName() {
		return publicationName;
	}

	public void setPublicationName(String publicationName) {
		this.publicationName = publicationName;
	}

	public int getUid() {
		return uid;
	}

	public void setUid(int uid) {
		this.uid = uid;
	}

	@Override
	public String toString() {
		return "FavouriteBook [bookId=" + bookId + ", bookName=" + bookName + ", authourName=" + authourName
				+ ", bookPrice=" + bookPrice + ", publicationName=" + publicationName + ", uid=" + uid + "]";
	}

}
