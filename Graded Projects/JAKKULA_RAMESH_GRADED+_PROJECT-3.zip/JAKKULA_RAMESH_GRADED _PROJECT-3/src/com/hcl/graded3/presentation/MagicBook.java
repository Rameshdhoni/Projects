package com.hcl.graded3.presentation;

import java.util.List;
import java.util.Scanner;

import com.hcl.graded3.pojo.Book;
import com.hcl.graded3.service.IBookService;
import com.hcl.graded3.service.IBookServiceImp;

public class MagicBook {
	public static final LogService LOGGER = new LogService();

	public static void main(String[] args) {
		Runnable r = new MythreadRunnable();
		Thread t = new Thread(r);
		t.start();
		System.out.println("**** welcome to magic book ****");

		boolean flag = true;
		Scanner scanner = new Scanner(System.in);

		while (flag) {
			LOGGER.log(" Menu execution started ");
			System.out.println("AS A ADMIN U HAVE BELOW OPERTAION TO DO");
			System.out.println("1. ADD BOOK");
			System.out.println("2. UPDATE BOOK");
			System.out.println("3. DELETE BY BOOKS ID");
			System.out.println("4. SELECT BY BOOKS ID");
			System.out.println("5. GET ALL BOOKS");
			System.out.println("6. PRICE FROM HIGH TO LOW");
			System.out.println("7. PRICE FROM LOW TO HIGH");
			System.out.println("8. HIGHEST NUMBER OF SALES/BEST SELLING ");
			System.out.println("9. AUTOBIOGRAPHY BOOKS");
			System.out.println("0. EXIST/LOGOUT");

			int key = scanner.nextInt();
			IBookService service = new IBookServiceImp();
			switch (key) {
			case 1:
				LOGGER.log(" add method execution started ");

				System.out.println("Enter bid");
				int bid = scanner.nextInt();
				System.out.println("book name ");
				String bookName = scanner.next();
				System.out.println("enter type of book(fav/new/completed) ");
				String typeOfBook = scanner.next();
				System.out.println("enter genrename ");
				String genreName = scanner.next();
				System.out.println("enter descrption ");
				String descrption = scanner.next();
				System.out.println("enter price");
				double bprice = scanner.nextDouble();
				System.out.println("enter noOfCopiesSold");
				int noOfCopiesSold = scanner.nextInt();
				Book book = new Book();
				book.setBid(bid);
				book.setBookName(bookName);
				book.setTypeOfBook(typeOfBook);
				book.setDescrption(descrption);
				book.setGenreName(genreName);
				book.setBprice(bprice);
				book.setNoOfCopiesSold(noOfCopiesSold);
				int count = service.addBook(book);
				if (count > 0) {
					System.out.println(count + "book added sucussfully");

				} else {
					System.out.println("added failed");
				}

				break;
			case 2:
				LOGGER.log(" update method execution started ");

				System.out.println("Enter existing bid");
				int bid1 = scanner.nextInt();
				System.out.println("book name ");
				String bookname1 = scanner.next();
				System.out.println("enter type of book(fav/new/completed) ");
				String typeOfBook1 = scanner.next();
				System.out.println("enter genrename ");
				String genreName1 = scanner.next();
				System.out.println("enter descrption ");
				String descrption1 = scanner.next();
				System.out.println("enter price");
				double bprice1 = scanner.nextDouble();
				System.out.println("enter noOfCopiesSold");
				int noOfCopiesSold1 = scanner.nextInt();
				Book book1 = new Book();
				book1.setBid(bid1);
				book1.setBookName(bookname1);
				book1.setTypeOfBook(typeOfBook1);
				book1.setGenreName(genreName1);
				book1.setDescrption(descrption1);
				book1.setBprice(bprice1);
				book1.setNoOfCopiesSold(noOfCopiesSold1);
				double count1 = service.updateBook(book1);
				if (count1 > 0) {
					System.out.println(count1 + "book updated sucussfully");

				} else {
					System.out.println("update failed");
				}

				break;
			case 3:
				LOGGER.log(" delete method execution started ");

				System.out.println("Enter Id to Delete book");
				int deleteId = scanner.nextInt();
				int n1 = service.deleteBookById(deleteId);
				if (n1 > 0) {
					System.out.println(n1 + "book deleted sucussfully");

				} else {
					System.out.println("deleted failed");
				}

				break;
			case 4:
				LOGGER.log(" searching book by id method execution started ");

				System.out.println("Enter  Id to Serach/select book");
				int searchId = scanner.nextInt();
				Book searchBook = service.selectBookById(searchId);
				if (searchBook != null) {
					System.out.println(searchBook);
				} else {
					System.out.println("book not found");
				}
				break;
			case 5:
				List<Book> bookList = service.selectAll();
				for (Book books : bookList) {
					System.out.println(books);
				}
				break;

			case 6:
				service.highToLow();
				break;
			case 7:
				service.lowToHigh();
				break;
			case 8:
				service.bestSelling();
				break;
			case 9:
				service.autoBioGraphy();
				break;
			case 0:

				flag = false;
				break;
			default:
				break;
			}
		}

	}

}
