create database capstoneproject;

use capstoneproject;

show tables;

select * from admin;

select * from users;

select * from posts;

select * from post_approve;

select * from  msg_tbl;

select * from reporteduser;