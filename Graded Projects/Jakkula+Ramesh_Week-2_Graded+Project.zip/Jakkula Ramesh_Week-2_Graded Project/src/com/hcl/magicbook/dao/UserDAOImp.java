package com.hcl.magicbook.dao;

import java.util.Arrays;
import java.util.List;

import com.hcl.magicbook.pojo.Book;
import com.hcl.magicbook.pojo.User;

public class UserDAOImp implements IuserDAO {
	User users[] = new User[3];
	
	User u1 = new User(101, "ramesh", "ramesh@gmail.com", "ramesh123");
	User u2 = new User(102, "rakesh", "rakesh@gmail.com", "rakesh123");
	User u3 = new User(103, "raju", "raju@gmail.com", "raju123");

	@Override
	public List<User> getAllUser() {
		
		users[0] = u1;
		users[1] = u2;
		users[2] = u3;
		List<User>userlist=Arrays.asList(users);
		return userlist;
	}

}
