package com.hcl.doctormicroservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hcl.doctormicroservice.entity.Doctor;
/*
 * @Author: Ramesh
 * Date: 23-12-2022
 */
//Creating automatic tables using entity class name and data type of primary key of table with JpaRepository
@Repository
public interface DoctorRepository extends JpaRepository<Doctor, Long> {

}
