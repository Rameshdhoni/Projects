import axios from "axios";
import React, { useState } from 'react';
import { useEffect } from 'react';
import Navbar from 'react-bootstrap/Navbar';
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Table from 'react-bootstrap/Table';
import Button from 'react-bootstrap/Button';
import './Menucrud.css';
import 'bootstrap/dist/css/bootstrap.min.css';






function Monthly(){

    //array
    var[post, setPost] = useState([]);
    var[product, SetProduct] = useState([]);
    var[cart, SetCart] = useState([]);

    var[newTitle, setNewTitle]= useState();
    var[newAuthor, setNewAuthor]=useState();
    var[newPass, setNewPass]=useState();

   

    function loadProductFromServer() {
        axios.get("http://localhost:3000/product").then((response) =>{
            SetProduct(response.data);
        })
    }

    loadProductFromServer();
    //console.log(product);
    

    function loadPostfromServer(){
        axios.get("http://localhost:3000/cart").then((response) => {
            console.log(response.data);
            // var startDate = new Date().getDate();
            // console.log(startDate);
            let startDate = new Date().toJSON().slice(0, 10);
            console.log(startDate);

        var resultProductData = response.data.filter(a => {
            var date = new Date(a.date);
            return (date >= startDate && date <= startDate);
});
console.log(resultProductData)

        SetCart(response.data);
        
     } )
    }
    

    useEffect(loadPostfromServer, []);
    function addData(event){
        event.preventDefault();
        const newPost = {
            name: newTitle,
            email: newAuthor,
            password: newPass
           
        };
        axios.post("http://localhost:3000/cart",newPost).then((res)=>{
            loadPostfromServer();
        })
    

    }
    

   

    return(


        <div>
            <Navbar bg="light" expand="lg">
        <Container>
          <Navbar.Brand href="#home">Surabhi Restaurant</Navbar.Brand>
          <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav">
            <Nav className="me-auto">
              <Nav.Link href="/Ahome">Home</Nav.Link>
              <Nav.Link href="/">Logout</Nav.Link>
  
            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>

    <Container>
        <h1 >Monthly Orders</h1>
      <Table striped bordered hover style={{margin:'20px'}}>
      <thead>
        <tr>
          <th>ID</th>
          <th>Item Name</th>
          <th>Category</th>
          <th>Price</th>
         
          <th>Ordered Date</th>
        </tr>
      </thead>
      <tbody>

                {cart.map(temp => {
                            var item = product.find(item => item.id == temp.id);

                            return(
                                <tr className="toptable">
                                    <td>{temp.id}</td>
                                    <td>{item.item}</td>
                                    <td>{item.category}</td>
                                    <td>{item.price}</td>
                                  
                                    <td>{temp.date}</td>
                                </tr>
                            )
                        })}


                </tbody>
    </Table>
    </Container>

            
        </div>
    )


}
export default Monthly;