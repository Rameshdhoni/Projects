package com.hcl.projectgraded.presentation;

import java.io.FileWriter;
import java.io.IOException;

public class LogService {

	FileWriter writer = null;

	public LogService() {
		try {
			writer = new FileWriter(" booklogger.txt", true);
		} catch (IOException e) {

			e.printStackTrace();
		}
	}

	public void log(String msg) {
		try {
			writer.append(msg + "\n");
			writer.flush();
		} catch (IOException e) {

			e.printStackTrace();
		}
	}
}
