package com.hcl.mp.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.hcl.mp.ui.LogService;

public class DBConnection {
	public static final LogService LOGGER = new LogService();
	private static String name="root";
	private static String password="Sql@12345";
	private static String url="jdbc:mysql://localhost:3306/surabirestaurant";
	private static String driver="com.mysql.cj.jdbc.Driver";
	
	private static Connection a=null;
	private DBConnection() {
		
	}
	public static synchronized Connection  getConnection() {
		LOGGER.log(" JDBC STEPS ");

		if(a==null) {
			try {
			// Step#1. Load the Driver class
			Class.forName(driver);
			// Step#2. Establish the connection
			a=DriverManager.getConnection(url, name, password);
			
		}
			catch(ClassNotFoundException e) {
				System.out.println("Driver not found"+e.getMessage());
				
			}
			catch(SQLException e) {
				System.out.println("DB issues..."+e.getMessage());
				
			}
		
		
	}
		return a;

}


}
