package com.hcl.projectgraded.beans;

import java.time.LocalDate;

public class Book {
	private int bid;
	private String bookName;
	private String typeOfBook;
	private String genreName;
	private String descrption;
	private double bprice;
	private int noOfCopiesSold;

	public Book() {
		super();
	}

	public Book(int bid, String bookName, String typeOfBook, String genreName, String descrption, double bprice,
			int noOfCopiesSold) {
		super();
		this.bid = bid;
		this.bookName = bookName;
		this.typeOfBook = typeOfBook;
		this.genreName = genreName;
		this.descrption = descrption;
		this.bprice = bprice;
		this.noOfCopiesSold = noOfCopiesSold;
	}

	public int getBid() {
		return bid;
	}

	public void setBid(int bid) {
		this.bid = bid;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public String getTypeOfBook() {
		return typeOfBook;
	}

	public void setTypeOfBook(String typeOfBook) {
		this.typeOfBook = typeOfBook;
	}

	public String getGenreName() {
		return genreName;
	}

	public void setGenreName(String genreName) {
		this.genreName = genreName;
	}

	public String getDescrption() {
		return descrption;
	}

	public void setDescrption(String descrption) {
		this.descrption = descrption;
	}

	public double getBprice() {
		return bprice;
	}

	public void setBprice(double bprice) {
		this.bprice = bprice;
	}

	public int getNoOfCopiesSold() {
		return noOfCopiesSold;
	}

	public void setNoOfCopiesSold(int noOfCopiesSold) {
		this.noOfCopiesSold = noOfCopiesSold;
	}

	@Override
	public String toString() {
		return "Book [bid=" + bid + ", bookName=" + bookName + ", typeOfBook=" + typeOfBook + ", genreName=" + genreName
				+ ", descrption=" + descrption + ", bprice=" + bprice + ", noOfCopiesSold=" + noOfCopiesSold + "]";
	}

}