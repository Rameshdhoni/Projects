package com.hcl.graded3.service;

import java.util.List;

import com.hcl.graded3.pojo.Book;

public interface IBookService {
	public int addBook(Book book);

	public int updateBook(Book book);

	public int deleteBookById(int bid);

	public Book selectBookById(int bid);

	public void highToLow();

	public void lowToHigh();

	public List<Book> selectAll();

	public void bestSelling();
	public void  autoBioGraphy();

}
