package com.hcl.doctormicroservice.service;

import java.util.List;

import com.hcl.doctormicroservice.dto.DoctorDTO;
import com.hcl.doctormicroservice.entity.Doctor;
import com.hcl.doctormicroservice.vo.DoctorDiagnosisVO;
import com.hcl.doctormicroservice.vo.DoctorPatientVO;
/*
 * @Author: Ramesh
 * Date: 23-12-2022
 */
public interface IDoctorService {
	//doctor CRUD operations
	public Doctor addDoctors(DoctorDTO dto);

	public Doctor getById(long id);

	public List<Doctor> getAll();
//doctor micro-service linked with other micro-services
	public DoctorDiagnosisVO getDoctorByIdWithDiagnosis(long doctorId);

	public DoctorPatientVO getDoctorByIdWithPatient(long doctorId);
	

}
