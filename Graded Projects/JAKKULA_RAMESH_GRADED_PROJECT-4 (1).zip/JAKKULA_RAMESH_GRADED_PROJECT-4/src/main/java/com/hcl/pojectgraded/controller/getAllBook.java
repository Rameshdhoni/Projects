package com.hcl.pojectgraded.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hcl.projectgraded.pojo.Book;
import com.hcl.projectgraded.service.IBookService;
import com.hcl.projectgraded.service.IBookServiceImp;
import com.hcl.projectgraded.service.IUserService;
import com.hcl.projectgraded.service.IUserServiceImp;

/**
 * Servlet implementation class getAllBook
 */
@WebServlet("/getAllBook")
public class getAllBook extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public getAllBook() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		IBookService service=new IBookServiceImp();
		
		List<Book> book= service.selectAll();
		for (Book book2 : book) {
			out.print(book2  +"  ");
			//out.print("<a href='WelcomeAdmin.jsp'> GO TO WELCOME ADMIN PAGE</a><br>");
		}out.print("<a href='WelcomeAdmin.jsp'> GO TO WELCOME ADMIN PAGE</a><br>");
		}
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
