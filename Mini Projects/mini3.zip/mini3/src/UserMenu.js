import React, {useState} from "react";
import { useEffect } from "react";
import axios from "axios";
import Wishlist from "./Wishlist";
// import "./Products.css";
import "./UserMenu.css";


function UserMenu() {

    //array
    var[product, SetProduct] = useState([]);

    var[cartId, setCartId] = useState();
    var[cartQuantity, setCartQuantity] = useState();
    var[cart, SetCart] = useState([]);

    var[displayTotal, setDisplayTotal] = useState(false);
    var sum = 0;

    var[wishlistId, setWishlistId] = useState();
    var[wishlist, setWishlist] = useState([]);

    var[displayWishlist, setDisplayWishlist] = useState(false);

     //function to get all the products from the json product server
    function loadProductFromServer() {
        axios.get("http://localhost:3000/product").then((response) =>{
            SetProduct(response.data);
        })
    } 
     //calling this method "loadProductFromServer", only once when component loaded
    useEffect(loadProductFromServer, []);

    
    //function to add the products into the json cart server 
    function addCart(event){
        event.preventDefault();
        const newCartProduct = {
            id: cartId,
            quantity: cartQuantity
        };
        axios.post("http://localhost:3000/cart", newCartProduct).then((response) => {
            loadCartFromServer();
            setCartId("");
            setCartQuantity("");
        })
    }

        //function to get all the products from the cart server
        function loadCartFromServer() {
        axios.get("http://localhost:3000/cart").then((response) =>{
            SetCart(response.data);
        })
    } 
    useEffect(loadCartFromServer, []);

    
    //function to add products into the wishlist server 
    function addWishlist(event) {
        event.preventDefault();

        const newWishlist = {
            id: wishlistId
        };
        axios.post("http://localhost:3000/wishlist", newWishlist).then((response) =>{
            loadWishlistFromServer();
            setWishlistId("");
        })
    }   

    //function to get all products from the wishlist server
    function loadWishlistFromServer(){
        axios.get("http://localhost:3000/wishlist").then((response) => {
            setWishlist(response.data);
        })
    }
    useEffect(loadWishlistFromServer, []);

    function handleWishlistDisplay() {
        if(displayWishlist){
            setDisplayWishlist(false);
        }
        else{
            setDisplayWishlist(true);
        }
        
    }


    return(
        <div className="main-container">
            <h2 className="main-title">WELCOME TO PRODUCTS SECTION</h2>
            <h4 className="title"> LIST OF PRODUCTS AVAILABLE </h4>
            <br/>
            <table border="1" className="tabledesign">
                <thead>
                    <tr className="toptable">
                        <th>ID</th>
                        <th>Product Name</th>
                        <th>Category</th>
                        <th>Description</th>
                        <th>Price</th>
                        
                    </tr>
                </thead>
                <tbody>
                    {
                        product.map(temp => {
                            return(
                                <tr className="toptable">
                                    <td>{temp.id}</td>
                                    <td>{temp.productname}</td>
                                    <td>{temp.category}</td>
                                    <td>{temp.description}</td>
                                    <td>{temp.price}</td>
                                </tr>
                            )
                        })
                    }
                </tbody>
            </table>
            <br/>

            
            
        </div>
    )
}

export default UserMenu;