package com.hcl.projectgraded.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.hcl.projectgraded.beans.User;


@Repository
public class IUserDaoImp implements IUserDao {
	Connection conn = DBFactory.getDBConnection();
	PreparedStatement pstmt;

	@Override
	public int addUser(User user) {
		String insertQuery = "insert into user(  userId, userName,email,address)values(?,?,?,?)";
		int count = 0;
		try {
			pstmt = conn.prepareStatement(insertQuery);
			pstmt.setInt(1, user.getUserId());
			pstmt.setString(2, user.getUserName());
			pstmt.setString(3, user.getEmail());
			pstmt.setString(4, user.getAddress());
			count = pstmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return count;
	}

	@Override
	public int updateUser(User user) {
		String updateQuery = "update user set userName = ? , email = ? , address = ?  where userId = ? ";
		
		int count = 0;
		try {
			pstmt = conn.prepareStatement(updateQuery);
			pstmt.setString(1,user.getUserName());
			pstmt.setString(2,user.getEmail());
			pstmt.setString(3,user.getAddress());
			pstmt.setInt(4,user.getUserId());
			
			count = pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return count;
	}

	@Override
	public int deleteUserById(int userId) {
		String deleteQuery = "delete from user where userId =?";
		int count = 0;
		try {
			pstmt = conn.prepareStatement(deleteQuery);
			pstmt.setInt(1, userId);

			count = pstmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return count;
	}

	@Override
	public User selectUserById(int userId) {
		String selectOne = "select * from user where userId=?";
		int count = 0;
		User user = new User();
		try {
			pstmt = conn.prepareStatement(selectOne);
			pstmt.setInt(1, userId);

			// count = pstmt.executeUpdate();
			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				int userId1 = rs.getInt("userId");
				String userName = rs.getString("userName");
				String email = rs.getString("email");
				String address = rs.getString("address");

				user.setUserId(userId);
				user.setUserName(userName);
				user.setEmail(email);
				user.setAddress(address);

			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return user;
	}

	@Override
	public List<User> selectAll() {
		List<User> userList = null;
		try {
			String selectQuery = "select * from user";
			pstmt = conn.prepareStatement(selectQuery);
			ResultSet rs = pstmt.executeQuery();
			userList = new ArrayList<User>();
			while (rs.next()) {
				int userId = rs.getInt(" userId");
				String userName = rs.getString("userName");
				String email = rs.getString(" email");
				String address = rs.getString(" address");
				User user = new User();
				user.setUserId(userId);
				user.setUserName(userName);
				user.setEmail(email);
				user.setAddress(address);

				userList.add(user);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return userList;
	}

}
