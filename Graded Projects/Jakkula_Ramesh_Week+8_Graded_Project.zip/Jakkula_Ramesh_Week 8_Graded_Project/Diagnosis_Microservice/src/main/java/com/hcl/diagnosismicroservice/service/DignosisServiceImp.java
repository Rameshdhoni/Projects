package com.hcl.diagnosismicroservice.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.diagnosismicroservice.dto.DiagnosisDTO;
import com.hcl.diagnosismicroservice.entity.Diagnosis;
import com.hcl.diagnosismicroservice.exception.DiagnosisNotFoundException;
import com.hcl.diagnosismicroservice.repository.DiagnosisRepository;
/*
 * @Author: Ramesh
 * Date: 23-12-2022
 */
@Service
public class DignosisServiceImp implements IDiagnosisService {
	@Autowired
	DiagnosisRepository repo;

//  Diagnosis  crud operations 
	@Override
	public Diagnosis add(DiagnosisDTO dto) {
		Diagnosis dia = new Diagnosis();
		dia.setDiagnosisId(dto.getDiagnosisId());
		dia.setDiagnosisName(dto.getDiagnosisName());
		dia.setDaignosisFee(dto.getDaignosisFee());
		dia.setPatientId(dto.getDiagnosisId());
		return repo.save(dia);
	}

	// getting particular Diagnosis details using id
	@Override
	public Diagnosis get(long id) {
		try {
			return repo.findById(id).orElse(null);
		} catch (Exception e) {
			throw new DiagnosisNotFoundException();
		}
	}

	// getting all Diagnosis details
	@Override
	public List<Diagnosis> getall() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

}
