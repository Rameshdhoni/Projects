package com.hcl.patientmicroservice.exception;
/*
 * @Author: Ramesh
 * Date: 23-12-2022
 */
public class PatientNotFoundException extends RuntimeException {

	private String message;

	public PatientNotFoundException(String message) {
		super(message);
		this.message = message;
	}

	public PatientNotFoundException() {
	}
}
