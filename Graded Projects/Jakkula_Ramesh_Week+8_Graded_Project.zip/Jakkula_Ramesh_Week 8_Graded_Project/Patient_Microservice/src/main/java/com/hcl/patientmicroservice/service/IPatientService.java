package com.hcl.patientmicroservice.service;

import java.util.List;

import com.hcl.patientmicroservice.dto.PatientDTO;
import com.hcl.patientmicroservice.entity.Patient;
/*
 * @Author: Ramesh
 * Date: 23-12-2022
 */
public interface IPatientService {
	// Patient Crud Opertaion
	public Patient addPatient(PatientDTO dto);

	public Patient getById(long id);

	public List<Patient> getAll();

}
