package com.hcl.graded3.presentation;

public class MythreadRunnable implements Runnable {
	public static final LogService LOGGER = new LogService();

	@Override
	public void run() {
		LOGGER.log(" Main method & Thread execution started ");

	}

}
