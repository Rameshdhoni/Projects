package com.hcl.diagnosismicroservice.service;

import java.util.List;

import com.hcl.diagnosismicroservice.dto.DiagnosisDTO;
import com.hcl.diagnosismicroservice.entity.Diagnosis;
/*
 * @Author: Ramesh
 * Date: 23-12-2022
 */
public interface IDiagnosisService {
	// Diagnosis crud operations
	public Diagnosis add(DiagnosisDTO dto);

	public Diagnosis get(long id);

	public List<Diagnosis> getall();

}
