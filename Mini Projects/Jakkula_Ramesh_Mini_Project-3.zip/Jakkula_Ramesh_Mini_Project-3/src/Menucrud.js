import axios from "axios";
import React, { useState } from 'react';
import { useEffect } from 'react';
import Navbar from 'react-bootstrap/Navbar';
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Table from 'react-bootstrap/Table';
import Button from 'react-bootstrap/Button';
import './Menucrud.css';
import 'bootstrap/dist/css/bootstrap.min.css';


function MenuCrud(){

    //array
    var[post, setPost] = useState([]);

    var[newId, setNewId]= useState();
    var[newItem, setNewItem]=useState();
    var[newcategory, setNewCategory]=useState();
    var[newPrice, setNewPrice]=useState();
   
    //updatinfg data
    var[oldId, setOldId]= useState();
    var[oldItem, setOldItem]=useState();
    var[oldcategory, setOldCategory]=useState();
    var[oldPrice, setOldPrice]=useState();

    var[deleteId, setdeleteId] = useState();

    
    



    function loadPostfromServer(){
        axios.get("http://localhost:3000/product").then((response) => {

        setPost(response.data);
        
     } )
    }
    

    useEffect(loadPostfromServer, []);
    function addData(event){
        event.preventDefault();
        const newPost = {
            id: newId,
            item: newItem,
            category:newcategory ,
            price: newPrice
        };
        axios.post("http://localhost:3000/product",newPost).then((res)=>{
            loadPostfromServer();
        })
    

    }
    function updateData(event){
        event.preventDefault();
        const oldPost = {
            id: oldId,
            item: oldItem,
            category:oldcategory ,
            price: oldPrice


        };
        axios.put("http://localhost:3000/product/"+oldId,oldPost).then((res)=>{
            loadPostfromServer();



        })
    }

    function deleteData(event){
        event.preventDefault();
        axios.delete("http://localhost:3000/product/"+deleteId).then((res)=>{
            loadPostfromServer();
    })
    }

    return(


<div>
            <Navbar bg="light" expand="lg">
        <Container>
          <Navbar.Brand href="#home">Surabhi Restaurant</Navbar.Brand>
          <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav">
            <Nav className="me-auto">
              <Nav.Link href="/Ahome">Home</Nav.Link>
              <Nav.Link href="/">Logout</Nav.Link>
  
            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>

    <Container>
      <Table striped bordered hover style={{margin:'20px'}}>
      <thead>
        <tr>
          <th>ID</th>
          <th>Item</th>
          <th>Category</th>
          <th>Price</th>
        </tr>
      </thead>
      <tbody>
                    {
                        post.map(temp => {
                            return(
                                <tr>
                                    <td>{temp.id}</td>
                                    <td>{temp.item}</td>
                                    <td>{temp.category}</td>
                                    <td>{temp.price}</td>
                                    <td><Button variant="primary" href="/Menucrud">Edit</Button></td>
                                    <td><Button variant="danger" href="/Menucrud" onClick="">Delete</Button></td>
                                </tr>
                            )
                        })
                    }


                </tbody>
    </Table>
    </Container>

            <hr></hr>
             <h1>Add Item</h1>
            <form onSubmit={addData}>
                <label>Id :</label>
                <input type="text"required value={newId} onChange={e=>setNewId(e.target.value)}/>
                <br></br>
                <label>ItemName :</label>
                <input type="text" required value={newItem} onChange={e=>setNewItem(e.target.value)}/>
                <br></br>
                <label>category :</label>
                <input type="text" required value={newcategory} onChange={e=>setNewCategory(e.target.value)}/>
                <br></br>
                <label>price:</label>
                <input type="text" required value={newPrice} onChange={e=>setNewPrice(e.target.value)}/>
                <br></br>
                <button type="submit">Add Data</button>
            </form> 

            <hr></hr>
             <h1>Update Item</h1>
            <form onSubmit={updateData}>
                <label>Id :</label>
                <input type="text"required value={oldId} onChange={e=>setOldId(e.target.value)}/>
                <br></br>
                <label>ItemName :</label>
                <input type="text" required value={oldItem} onChange={e=>setOldItem(e.target.value)}/>
                <br></br>
                <label>category :</label>
                <input type="text" required value={oldcategory} onChange={e=>setOldCategory(e.target.value)}/>
                <br></br>
                <label>price:</label>
                <input type="text" required value={oldPrice} onChange={e=>setOldPrice(e.target.value)}/>
                <br></br>
                <button type="submit">Add Data</button>
            </form> 
            

            <hr></hr>
            <div id="delete">
            <h1>delete Item</h1>
            <form onSubmit={deleteData}>
            <label>ID data u want to delete :</label>
                <input type="number" required onChange={e=>setdeleteId(e.target.value)}/>
                <br></br>
                <button type="submit">Delete Data</button>
                </form></div>
</div>
        
    )


}
export default MenuCrud;