let homeCareItems=[
    {
        productname:"Glass Cleaner",
         price : 20,
         Quantity:1
    },
    {
        productname:"Detergents",
        price : 50,
        Quantity:2

    },{

        productname:"Soaps",
        price : 50,
        Quantity:1
    },{
        productname:"Water bottle",
        price : 15,
        Quantity:1
    }

]
    let homeCare=()=>{
        console.log( homeCareItems)
    }
    homeCare();