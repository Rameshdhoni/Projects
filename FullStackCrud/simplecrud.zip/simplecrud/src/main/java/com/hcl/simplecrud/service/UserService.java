package com.hcl.simplecrud.service;

import java.util.List;
import java.util.Optional;

import com.hcl.simplecrud.entity.User;

public interface UserService {
	public User newUser(User newUser);

	public List<User> getAllUsers();

	public Optional<User> getUserById(Long id);

	public User updateUser(User newUser,Long id);

	public String deleteUser(Long id);
}
