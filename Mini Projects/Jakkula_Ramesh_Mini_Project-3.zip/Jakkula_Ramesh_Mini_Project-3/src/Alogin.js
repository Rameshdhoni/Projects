import React from "react";
import {Outlet, Link} from "react-router-dom";
import './Login.css';
import { useNavigate } from "react-router-dom";
import { useState } from "react";
import axios from "axios";
import 'bootstrap/dist/css/bootstrap.min.css';
import Navbar from 'react-bootstrap/Navbar';
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';

function Alogin() {

    const [em, changeem] = useState("");
  const [pa, changepa] = useState("");

  var [email, setEmail] = useState();
    var [password, setPassword] = useState();
    var [errorMessage, setErrorMessage] = useState();
    var nav = useNavigate();

  
   function nextpage() {
     nav("/register");// or <register></register>
  }

  

  function handlesubmit(e) {
    e.preventDefault();
    if (em.length === 0 || pa.length === 0) {
      alert("It cant be empty");
    } else {
        const loginemail = {
            email: em
        };



       
        
        axios.get("http://localhost:3000/admin/").then((response) =>{
            
        response.data.forEach(element => {
          if(element.email === em && element.password === pa){
            nav("/Ahome");
          }else{
            alert("wrong email or password");
          }
          
        });
          
        })
        
    
    }
  }

  function onemail(e) {
    changeem(e.target.value);
  }
  function onpass(e) {
    changepa(e.target.value);
  }

  function checkLogin(){
    axios.get("http://localhost:3000/admin?email=" + email).then((res)=>{
      console.log(res)
        if( res.data == "" ){
            setErrorMessage("Invalid email and password");
            return;
        }
        else{
            if( res.data[0].password.localeCompare(password) == 0 ){
                //success
                localStorage.setItem("login", 1);
                localStorage.setItem("loginid", res.data[0].id);
                nav("/Ahome");
            }
            else{
                setErrorMessage("Invalid email and password");
                return;
            }
        }
    })
}
    
    return (
      <>
        <div>
          <Navbar bg="light" expand="lg">
      
        <h3>Surabhi Restaurant</h3>
          <Nav className="me-auto">
            <Nav.Link href="/"></Nav.Link>
            <Nav.Link href="/Login">Login</Nav.Link> {/* we can also use like this <NavLink to="/Login">Loginnn</NavLink> */}
            <Nav.Link href="/Register">Register</Nav.Link>
            <Nav.Link href="/">Logout</Nav.Link>

          </Nav>
    
      
    </Navbar>

                <div className="maindivv">
      <div className="box">
        <h1> SIGN IN </h1>
        <br></br>
        <h3 className="text-danger">{errorMessage}</h3>
       
          <div className="grp">
            <label htmlFor="email">Email:</label>
            <input
              type="email"
              name="email"
              id="email"
              placeholder="Enter Email" onChange={e => (setEmail(e.target.value))}
            />
          </div>

          <div className="grp">
            <label htmlFor="password">Password:</label>
            <input
              type="password"
              name="password"
              id="password"
              placeholder="Enter Password"  onChange={e => (setPassword(e.target.value))} 
            />
          </div>
          <input class="btn-submit" type="submit" value="SIGN IN" onClick={checkLogin}></input>
        
        <br />
        <br />

        <p>
          Don't have an account ? &nbsp; &nbsp; &nbsp;{" "}
          <button className="btn" onClick={nextpage}>
            {" "}
            Sign Up
          </button>{" "}
        </p>
      </div>
    </div>
   
        </div> 

        </>
    );
    }

export default Alogin;