import React from "react";
import { Link} from "react-router-dom";
//import './Mainpage.css';
import { Button } from 'react-bootstrap';
import items from './items.jpg'
import item from './item.jpg'
function Mainpage() {

    return(
        <div className="outside">
            <h1 className="header" style={{color:"Red",textAlign:"center"}} >Welcome to Surabi Chain Of Restaurants</h1>
                <br/>
                <div className="Butt">
                    <Button>
                    <Link to="/User" className="links">User</Link>
                    </Button>
                    <Button>
                    <Link to="/Admin" className="links">Admin</Link>
                    </Button><br></br>
                 
                    <img src={item}  alt="item" height={"500"} width={"1000"} style={{border:"4cm",borderBlock:"red"}} className="conatiner" borderWidth="2px solid"></img> 
                    <img src={items} alt="mypic" height={"500"} width={'400'}></img>
    
                </div>
        </div>
    );
}

export default Mainpage;