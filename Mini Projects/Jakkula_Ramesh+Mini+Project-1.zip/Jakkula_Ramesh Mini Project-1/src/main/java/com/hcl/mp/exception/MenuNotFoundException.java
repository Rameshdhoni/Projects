package com.hcl.mp.exception;

public class MenuNotFoundException extends Exception{
	
	public MenuNotFoundException(String msg) {
		super(msg);
	}

}
