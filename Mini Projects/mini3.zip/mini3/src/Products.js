import React, {useState} from "react";
import { useEffect } from "react";
import axios from "axios";

import "./Products.css";
import {NavLink, useNavigate} from 'react-router-dom';
import { Nav } from "react-bootstrap";

function Products() {

    //array
    var[product, SetProduct] = useState([]);

    var[cartId, setCartId] = useState();
    var[cartQuantity, setCartQuantity] = useState();
    var[cart, SetCart] = useState([]);
    //var[cartItem,setCartItem]=useState([]);
    var[displayTotal, setDisplayTotal] = useState(false);
    var sum = 0;

    var [products, setProducts]  = useState([]);
var date= new Date();
    var nav = useNavigate();

     //function to get all the products from the json product server
    function loadProductFromServer() {
        axios.get("http://localhost:3000/product").then((response) =>{
            SetProduct(response.data);
        })
    } 
     //calling this method "loadProductFromServer", only once when component loaded
    useEffect(loadProductFromServer, []);
   
    var [products, setProducts]  = useState([]);

    var nav = useNavigate();

    function getProducts(){
       
        axios.get("http://localhost:3000/products").then((res)=> {
            setProducts(res.data);
        });
    }


    function addToCart(id){
        //check login
        if( localStorage.getItem("login") == null ){
            alert("No login found. Please login/register");
            nav("/login");
            return; //stop the function execution
        }
        else{
            //add the information [productId, userId] to the cart
            var userId = localStorage.getItem("loginid");
            debugger;
            console.log(userId)

            var tempName = "";
            var tempPrice = 0;
            product.map(temp => {
                if( id == temp.id ){
                    tempName = temp.productname;
                    tempPrice = temp.price;
                 
                }
            });

            var newCart = {
                "productId" : Number(id),
                "price" : tempPrice,
                "name" : tempName,
                "userId": userId,
                date: new Date().toLocaleString()
            };

            axios.post("http://localhost:3000/cart", newCart).then((response) => {
            loadCartFromServer();
            setCartId("");
            setCartQuantity("");
        });

        }
    }

        //function to get all the products from the cart server
        function loadCartFromServer() {
        axios.get("http://localhost:3000/cart").then((response) =>{
            SetCart(response.data);
        })
    } 
    useEffect(loadCartFromServer, []);
    
    useEffect(getProducts, []);

    
   
    return(
        <div className="main-container">
            <nav >
            <NavLink  to="/" style={{color:"red"}} >Logout</NavLink>
            </nav>
            <h2 className="main-title">WELCOME TO PRODUCTS SECTION</h2>
            <h4 className="title"> LIST OF PRODUCTS AVAILABLE </h4>
            <br/>
            <table border="1" className="tabledesign">
                <thead>
                    <tr className="toptable">
                        <th>ID</th>
                        <th>Item Name</th>
                        <th>Category</th>
                        <th>Price</th>
                        
                    </tr>
                </thead>
                <tbody>
                    {
                        product.map(temp => {
                            return(
                                <tr className="toptable">
                                    <td>{temp.id}</td>
                                    <td>{temp.item}</td>
                                    <td>{temp.category}</td>
                                    <td>{temp.price}</td>
                                </tr>
                            )
                        })
                    }
                </tbody>
            </table>
            <br/>

            <hr></hr>
            <br/>
            
            <div className="carttable">
            <h4 className="title1">ADD PRODUCT TO YOUR CART</h4>
            <br/>
            <form>
                <label className="side">ID : </label>
                <input className="side-input" type="number" required value={cartId} onChange={e=>setCartId(e.target.value)} />
                <br/><br/>
               
                <label className="side">QUANTITY : </label>
                <input className="side-input1" type="number" required value={cartQuantity} onChange={e=>setCartQuantity(e.target.value)} />
                <br/><br/>
               
                <button className="btn" type="submit"  onClick={() => addToCart(cartId)}>Click to add cart</button>  
                <button className="btn" type="sumbit" onClick={() => setDisplayTotal(true)}>Generate Bill</button>
           
            </form>

            <br/>       
            <h4 className="title1" style={{color:"Red",textAlign:"left"}}> PRODUCTS ADDED TO YOUR CART </h4>
            <br/>
            <table border="1" align="centre">
                <thead>
                    <tr className="toptable1">
                        <th>ID</th>
                        <th>Price</th>
                        <th>category</th>
                        <th>date</th>
                       
                    </tr>
                </thead>
                <tbody>
                    {
                        cart.map(temp => {
                            var item = product.find(item => item.id == temp.id);
                            //debugger;
                            sum=(sum+ temp.quantity*item.price);

                            
                            return(
                                <tr className="toptable">
                                    <td>{temp.id}</td>
                                    <td>{temp.price}</td>
                                     <td>{item.category}</td>
                                     <td >{date.getDate}</td>
                                   
                                   
                                </tr>
                            )
                        })
                    }
                </tbody>
            {displayTotal && <b className="bill">Your total bill is : {sum} Rs</b>}
            </table> 
            </div>

            <hr></hr>
            <br/>

          
        </div>
    )
}

export default Products;