package com.hcl.exception;

public class BookNotFoundException extends Exception {

}
