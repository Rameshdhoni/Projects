package com.hcl.gradedproject6.service;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.hcl.gradedproject6.entities.Admin;
import com.hcl.gradedproject6.entities.Book;
import com.hcl.gradedproject6.entities.FavouriteBook;
import com.hcl.gradedproject6.entities.User;

@Service
public interface IUserService {
	public User addUser(User user);

	public Book searchBookById(int bookId);

	public Book searchBookByAuthourName(String authourName);

	public Book searchBookByBookName(String bookName);

	public Book searchBookByPublicationName(String publicationName);

	List<Book> sortBookByPrice();

	public List<Book> getAllBook();

	List<Book> searchBookByPriceRange(int low, int high);
	public ResponseEntity<String> registerUser(User user);

	public User findByuname(String uname);
	public FavouriteBook addFavouriteBook(FavouriteBook book);

}
