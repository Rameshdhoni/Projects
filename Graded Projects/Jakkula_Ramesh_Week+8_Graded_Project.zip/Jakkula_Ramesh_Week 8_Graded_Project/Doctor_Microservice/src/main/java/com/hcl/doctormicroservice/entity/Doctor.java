package com.hcl.doctormicroservice.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
/*
 * @Author: Ramesh
 * Date: 23-12-2022
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Entity
@Table(name = "Doctor_Table")
public class Doctor {
	@Id
	@NotNull
	private long doctorId;
	@NotBlank
	private String doctorName;
	@NotNull
	private long patientId;
	@NotNull
	private long diagnosisId;

}
