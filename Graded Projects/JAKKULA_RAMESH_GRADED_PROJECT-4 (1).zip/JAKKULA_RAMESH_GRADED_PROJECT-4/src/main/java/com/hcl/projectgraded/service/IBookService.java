package com.hcl.projectgraded.service;

import java.util.List;

import com.hcl.projectgraded.pojo.Book;

public interface IBookService {
	public int addBook(Book book);

	public int updateBook(Book book);

	public int deleteBookById(int bid);

	public Book selectBookById(int bid);

	public void highToLow();

	public void lowToHigh();

	public List<Book> selectAll();

	public void bestSelling();
	public void  autoBioGraphy();

}
