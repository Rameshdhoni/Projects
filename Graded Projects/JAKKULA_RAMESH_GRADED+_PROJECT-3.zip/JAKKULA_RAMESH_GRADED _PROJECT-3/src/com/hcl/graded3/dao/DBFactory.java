package com.hcl.graded3.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.hcl.graded3.presentation.LogService;
import com.mysql.cj.jdbc.Driver;
import com.mysql.cj.xdevapi.DbDocFactory;

public class DBFactory {
	private static Connection conn;
	public static final LogService LOGGER = new LogService();

	private DBFactory() {

	}

	public static Connection getDBConnection() {
		if (conn == null) {
			LOGGER.log(" connecting jdbc steps ");

			try {
				DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
				conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/magicbook", "root", "Sql@12345");
			} catch (SQLException e) {

				e.printStackTrace();
			}

		}
		return conn;
	}

}
