package com.hcl.mp.dao;

import com.hcl.mp.pojo.FoodItem;

public interface MenuDAO {
	
	public void displayItems();

	public void addFoodItems(FoodItem item, String category);

	public void deleteFoodItems(int id);

	public void updateFoodItems(String name, int id, int price);

	public void showFoodItems();

	public void billsGeneratedToday();

	public void totalSale();

	public void orderItems();

	public void userFinalBill(int key, int noOfPlates);

	public void emptyBill();

}
