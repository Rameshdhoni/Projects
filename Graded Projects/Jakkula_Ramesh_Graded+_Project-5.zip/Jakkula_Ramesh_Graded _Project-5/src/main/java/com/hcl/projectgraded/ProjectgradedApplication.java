package com.hcl.projectgraded;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectgradedApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectgradedApplication.class, args);
	}

}
