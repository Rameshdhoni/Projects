import React from "react";
import {Outlet, Link} from "react-router-dom";
import 'bootstrap/dist/css/bootstrap.min.css';
import Navbar from 'react-bootstrap/Navbar';
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import NavDropdown from 'react-bootstrap/NavDropdown';
import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';

function Ahome() {

    return(
        <>
        <Navbar bg="light" expand="lg">
       <h1>Welcome to Surabhi Restaurant and admin </h1>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">{/* hoding navbar content */}
          <Nav className="me-auto">
            <Nav.Link href="/"></Nav.Link>
            <Nav.Link href="/">Logout</Nav.Link>
          </Nav>
        </Navbar.Collapse>
      
    </Navbar>
    <Row>
    <Col sm={3}>

<Card style={{ width: '15rem',margin:'50px' }}>
<Card.Body>
<Card.Title>Menu CRUD</Card.Title>
<Card.Text>
In Menu Crud ,Admin can do some Operation like adding item,updating item,deleting item  on menu .
</Card.Text>
<Button variant="primary" href="/Menucrud">Menu CRUD</Button>
</Card.Body>
</Card>

</Col>

        <Col sm={3}>

        <Card style={{ width: '15rem',margin:'50px' }}>
<Card.Body>
  <Card.Title>User CRUD </Card.Title>
  <Card.Text>
  In User Crud ,Admin can do some Operation like adding user,updating user,deleting user  on users .
  </Card.Text>
  <Button variant="primary" href="/Usercrud" >User CRUD</Button>
</Card.Body>
</Card>

        </Col>

        <Col sm={3}>

<Card style={{ width: '15rem',margin:'50px' }}>
<Card.Body>
<Card.Title>Todays Sales</Card.Title>
<Card.Text>
Admin can see the bill Genarate and Sales related to today and get an idea about sales in his Restaurant.
</Card.Text>
<Button variant="primary" href="/today">Today's sale</Button>
</Card.Body>
</Card>

</Col>

<Col sm={3}>

<Card style={{ width: '15rem',margin:'50px' }}>
<Card.Body>
<Card.Title>Monthly Bill</Card.Title>
<Card.Text>
Admin can see the Monthly bill in his Restaurant and get an idea about sales in his Restaurant
</Card.Text>
<Button variant="success" href="/MonthlySale">Genarate Bill</Button>
</Card.Body>
</Card>

</Col>
      </Row>
      

</>

    );
}

export default Ahome;