package com.hcl.patientmicroservice.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
/*
 * @Author: Ramesh
 * Date: 23-12-2022
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
public class Patient {
	@Id
	@NotNull
	private long patientId;
	@NotBlank
	private String patientName;
	@Email
	private String email;
	@NotNull
	private long diagnosisId;
	@NotNull
	private long consultantId;
}