package com.hcl.magicbook.dao;

import java.util.Arrays;
import java.util.List;

import com.hcl.magicbook.pojo.Book;

public class BookDAOImp implements IBookDAO {
	Book newbook[] = new Book[3];
	Book favbook[] = new Book[3];
	Book completedbook[] = new Book[3];
	Book nb1 = new Book("C programmming", "greg perry", "begineer to advanced", 200);
	Book nb2 = new Book("python", "john mnemong", "learn from zero", 201);
	Book nb3 = new Book(" core java", "gary cornell", "basics level", 202);
	Book fav1 = new Book("Romeo and Juliet", "william shakespeare", "love", 203);
	Book fav2 = new Book("power of patience", "ryan", "make perfect", 204);
	Book fav3 = new Book(" something im waiting to tell you", "shravya", "never give up", 205);

	Book cb1 = new Book("Geethanjali", "rabindra nath tagore", "philosophy", 206);
	Book cb2 = new Book("network theory", "chakrabathi", "electrical networks", 207);
	Book cb3 = new Book("Dc machines", "gupta", "electrical world", 208);

	@Override
	public List<Book> getAllBooks() {

		newbook[0] = nb1;
		newbook[1] = nb2;
		newbook[2] = nb3;
		List<Book> newbooklist = Arrays.asList(newbook);
		return newbooklist;
	}

	@Override
	public List<Book> getAllFavBooks() {

		favbook[0] = fav1;
		favbook[1] = fav2;
		favbook[2] = fav3;
		List<Book> favbooklist = Arrays.asList(favbook);
		return favbooklist;

	}

	@Override
	public List<Book> getAllCompletedBooks() {

		completedbook[0] = cb1;
		completedbook[1] = cb2;
		completedbook[2] = cb3;
		List<Book> completedbooklist = Arrays.asList(completedbook);
		return completedbooklist;
	}

}
