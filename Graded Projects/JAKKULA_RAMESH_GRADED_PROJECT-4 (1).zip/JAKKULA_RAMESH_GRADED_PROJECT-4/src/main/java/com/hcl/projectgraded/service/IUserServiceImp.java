package com.hcl.projectgraded.service;

import java.util.List;

import com.hcl.projectgraded.dao.IUserDaoImp;
import com.hcl.projectgraded.pojo.User;

public class IUserServiceImp implements IUserService {
	IUserDaoImp dao;

	public IUserServiceImp() {
		dao = new IUserDaoImp() ;
	}
	@Override
	public int addUser(User user) {
		// TODO Auto-generated method stub
		return dao.addUser(user);
	}

	@Override
	public int updateUser(User user) {
		// TODO Auto-generated method stub
		return dao.updateUser(user);
	}

	@Override
	public int deleteUserById(int userId) {
		// TODO Auto-generated method stub
		return dao.deleteUserById(userId);
	}

	@Override
	public User selectUserById(int userId) {
		// TODO Auto-generated method stub
		return dao.selectUserById(userId);
	}

	@Override
	public List<User> selectAll() {
		// TODO Auto-generated method stub
		return dao.selectAll();
	}

}
