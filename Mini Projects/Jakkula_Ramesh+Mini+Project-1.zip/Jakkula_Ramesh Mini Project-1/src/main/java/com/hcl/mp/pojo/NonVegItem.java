package com.hcl.mp.pojo;

public class NonVegItem {
private String category = "Non-Veg";
	
	private FoodItem foodItem;
	
	public NonVegItem(FoodItem foodItem) {
		this.foodItem = foodItem;
	}
	
	public int getId() {
		return foodItem.getId();
	}

	public void setId(int id) {
		this.setId(id);
	}

	public String getCategory() {
		return category;
	}
	
	public String getItemName() {
		return foodItem.getItemName();
	}

	public void setItemName(String itemName) {
		this.setItemName(itemName);
	}
	public int getPrice() {
		return foodItem.getPrice();
	}
	public void setPrice(int price) {
		this.setPrice(price);
	}

	@Override
	public String toString() {
		return "NonVeg [foodItem=" + foodItem + "]";
	}


}
