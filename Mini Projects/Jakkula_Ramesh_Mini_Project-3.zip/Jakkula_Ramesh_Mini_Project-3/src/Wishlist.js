import React from 'react';
import "./Wishlist.css";


function Wishlist({wishlist, product}) {
  return (
    
         <div>
            <br/><br/>
            <table border="1">
                <thead>
                    <tr className="toptable">
                        <th>ID</th>
                        <th>Product Name</th>
                        <th>Price</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        wishlist.map(temp => {
                            var item = product.find(item => item.id == temp.id);

                            return(
                                <tr className="toptable">
                                    <td>{temp.id}</td>
                                    <td>{item.productname}</td>
                                    <td>{item.price}</td>
                                </tr>
                            )
                        })
                    }
                </tbody>
            </table>
      
    </div>
   
  )
}

export default Wishlist;
