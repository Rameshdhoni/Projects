package com.hcl.gradedproject6.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.hcl.gradedproject6.entities.Admin;
import com.hcl.gradedproject6.entities.Book;
import com.hcl.gradedproject6.repositories.AdminRepository;
import com.hcl.gradedproject6.repositories.BookRepository;

@Service
public class IAdminServiceImp implements IAdminService {
	@Autowired
	BookRepository repo;
	@Autowired
	AdminRepository adminRepo;

	
	  @Override public ResponseEntity<String> registerAdmin(Admin admin) {
	  ResponseEntity<String> response = null;
	  Admin admi = adminRepo.save(admin); 
	  if
	  (admi != null) {
		  response = new  ResponseEntity<String>("admin registration done", HttpStatus.ACCEPTED); }
	  else { 
		  response = new ResponseEntity<String>("admin registration Failed", HttpStatus.NOT_ACCEPTABLE);
		  } 
	  return response; 
	  }
	 

	@Override
	public Book insertBook(Book book) {
		// TODO Auto-generated method stub
		return repo.save(book);
	}

	@Override
	public Book updateBook(Book book) {
		// TODO Auto-generated method stub
		return repo.save(book);
	}

	@Override
	public String removeBook(int bookId) {
		repo.deleteById(bookId);
		return "deleted sucussfully";

	}

	@Override
	public List<Book> getAllBook() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	@Override
	public Book searchBookById(int bookId) {
		// TODO Auto-generated method stub
		return repo.findById(bookId).orElse(null);
	}

	@Override
	public Book searchBookByAuthourName(String authourName) {
		// TODO Auto-generated method stub
		return repo.searchBookByAuthourName(authourName);
	}


	@Override
	public Admin findByaName(String aName) {
		// TODO Auto-generated method stub
		return adminRepo.findByaName(aName);
	}


	
	


	
	

	
}
