package com.hcl.doctormicroservice.vo;

import com.hcl.doctormicroservice.dto.Diagnosis;
import com.hcl.doctormicroservice.dto.Patient;
import com.hcl.doctormicroservice.entity.Doctor;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
/*
 * @Author: Ramesh
 * Date: 23-12-2022
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class DoctorPatientVO {
	private Doctor doctor;
	private Patient patient;
	// VO: Value Object Usually used for data transfer between business tiers
}
