package com.hcl.patientmicroservice.restcontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.patientmicroservice.dto.PatientDTO;
import com.hcl.patientmicroservice.entity.Patient;
import com.hcl.patientmicroservice.service.IPatientService;
/*
 * @Author: Ramesh
 * Date: 23-12-2022
 */
@RestController
@RequestMapping("/api/patient") // base url of controller
public class PatientController {
	@Autowired
	IPatientService service;

//patient crud operations and taking input from user using postman,soap-ui or swagger
	@PostMapping("/add")
	public Patient addPatient(@RequestBody PatientDTO dto) {

		return service.addPatient(dto);
	}

//getting particular patient details using id  
	@GetMapping("/get/{id}")
	public Patient getById(@PathVariable long id) {
		return service.getById(id);
	}

//getting all patient details 
	@GetMapping("/getAll")
	public List<Patient> getAll() {
		return service.getAll();
	}
}
