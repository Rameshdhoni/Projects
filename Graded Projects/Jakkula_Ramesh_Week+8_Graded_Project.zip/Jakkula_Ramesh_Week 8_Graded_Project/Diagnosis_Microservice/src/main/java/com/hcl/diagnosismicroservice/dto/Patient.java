package com.hcl.diagnosismicroservice.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
/*
 * @Author: Ramesh
 * Date: 23-12-2022
 */
//Data Transfer Object (DTO) class is a java-bean like artifact that holds the data that you want to share between layer in your SW architecture. 
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Patient {
	private long diagnosisId;
	private String diagnosisName;
	private int daignosisFee;
	private long patientId;
}
