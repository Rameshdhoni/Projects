package com.hcl.magicbook.dao;

import com.hcl.magicbook.pojo.User;

public interface IuserDAO {
	public abstract User[] getAllUser();
}
