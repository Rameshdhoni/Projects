package com.hcl.doctormicroservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.doctormicroservice.dto.DoctorDTO;
import com.hcl.doctormicroservice.entity.Doctor;
import com.hcl.doctormicroservice.service.IDoctorService;
import com.hcl.doctormicroservice.vo.DoctorDiagnosisVO;
import com.hcl.doctormicroservice.vo.DoctorPatientVO;
/*
 * @Author: Ramesh
 * Date: 23-12-2022
 */
@RestController
@RequestMapping("/api/doctor")
public class DoctorController {
	@Autowired
	IDoctorService service;

	// doctor crud operation and taking values from user as input
	@PostMapping("/adddoctors")
	public Doctor addDoctors(@RequestBody DoctorDTO dto) {
		return service.addDoctors(dto);
	}

	@GetMapping("/get/{id}")
	public Doctor getById(@PathVariable long id) {
		return service.getById(id);
	}

	@GetMapping("/getAll")
	public List<Doctor> getAll() {
		return service.getAll();
	}

	@GetMapping("/get-doctor-diagnosis/{doctorId}")
	public DoctorDiagnosisVO getDoctorByIdWithDiagnosis(@PathVariable long doctorId) {
		return service.getDoctorByIdWithDiagnosis(doctorId);
	}

	@GetMapping("/get-doctor-patient/{doctorId}")
	public DoctorPatientVO getDoctorByIdWithPatient(@PathVariable long doctorId) {
		return service.getDoctorByIdWithPatient(doctorId);
	}
}
