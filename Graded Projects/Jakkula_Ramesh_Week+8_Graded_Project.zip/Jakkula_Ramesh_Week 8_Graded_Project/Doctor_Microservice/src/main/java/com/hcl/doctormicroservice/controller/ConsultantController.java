package com.hcl.doctormicroservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.doctormicroservice.dto.ConsultantDTO;
import com.hcl.doctormicroservice.entity.Consultant;
import com.hcl.doctormicroservice.service.IConsultantService;
/*
 * @Author: Ramesh
 * Date: 23-12-2022
 */
@RestController
@RequestMapping("/api/consultants")
public class ConsultantController {
	@Autowired
	IConsultantService service;

//Consultant crud operation and taking values from user as input
	@PostMapping("/addconsultant")
	public Consultant addConsultants(@RequestBody ConsultantDTO dto) {
		return service.addConsultants(dto);
	}

	@GetMapping("/get/{id}")
	public Consultant getById(@PathVariable long id) {
		return service.getById(id);
	}

	@GetMapping("/getAll")
	public List<Consultant> getAll() {
		return service.getAll();
	}
}
