package com.hcl.projectgraded.service;

import java.util.List;

import com.hcl.projectgraded.dao.IBookDaoImp;
import com.hcl.projectgraded.pojo.Book;
import com.hcl.projectgraded.presentation.LogService;


public class IBookServiceImp implements IBookService {
	public static final LogService LOGGER = new LogService();
	IBookDaoImp dao;

	public IBookServiceImp() {
		dao = new IBookDaoImp();
	}

	@Override
	public int addBook(Book book) {
		// TODO Auto-generated method stub
		return dao.addBook(book);
	}

	@Override
	public int updateBook(Book book) {
		// TODO Auto-generated method stub
		return dao.updateBook(book);
	}

	@Override
	public int deleteBookById(int bid) {
		// TODO Auto-generated method stub
		return dao.deleteBookById(bid);
	}

	@Override
	public Book selectBookById(int bid) {
		// TODO Auto-generated method stub
		return dao.selectBookById(bid);
	}

	@Override
	public List<Book> selectAll() {
		// TODO Auto-generated method stub
		return dao.selectAll();
	}

	@Override
	public void highToLow() {
		// TODO Auto-generated method stub
		dao.highToLow();
	}

	@Override
	public void lowToHigh() {
		// TODO Auto-generated method stub
		dao.lowToHigh();
	}

	@Override
	public void bestSelling() {
		dao.bestSelling();
		
	}

	@Override
	public void autoBioGraphy() {
		// TODO Auto-generated method stub
		dao.autoBioGraphy();
	}

}
