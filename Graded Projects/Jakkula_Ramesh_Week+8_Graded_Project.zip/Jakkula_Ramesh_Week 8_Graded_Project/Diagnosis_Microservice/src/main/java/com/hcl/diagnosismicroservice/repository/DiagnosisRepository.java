package com.hcl.diagnosismicroservice.repository;
/*
 * @Author: Ramesh
 * Date: 23-12-2022
 */
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hcl.diagnosismicroservice.entity.Diagnosis;
@Repository
public interface DiagnosisRepository extends JpaRepository<Diagnosis, Long> {
	//Creating automatic tables using entity class name and data type of primary key of table with JpaRepository
}
