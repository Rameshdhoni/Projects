package com.hcl.patientmicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PatientMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
