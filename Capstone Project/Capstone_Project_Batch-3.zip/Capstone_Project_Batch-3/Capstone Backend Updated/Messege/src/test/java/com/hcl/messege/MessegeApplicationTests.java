package com.hcl.messege;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MessegeApplicationTests {

	@Test
	void contextLoads() {
	}

}
