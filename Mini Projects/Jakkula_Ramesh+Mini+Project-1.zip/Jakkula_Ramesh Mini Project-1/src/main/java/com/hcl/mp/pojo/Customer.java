package com.hcl.mp.pojo;

public class Customer extends User{
	private String userType = "Customer";
	private User user;
	
	
	public Customer(User user) {
		this.user = user;
	}

	public String getUserType() {
		return userType;
	}
	
	
	public String getName() {
		return user.getName();
	}

	public void setName(String name) {
		this.user.setName(name);;
	}

	public String getEmail() {
		return user.getEmail();
	}

	public void setEmail(String email) {
		this.user.setEmail(email);;
	}

	public String getPassword() {
		return user.getPassword();
	}

	public void setPassword(String password) {
		this.user.setPassword(password);;
	}

	@Override
	public String toString() {
		return "Customer [userType=" + userType + ", user=" + user + "]";
	}
	
	

}
