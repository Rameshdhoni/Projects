package com.hcl.doctormicroservice.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
/*
 * @Author: Ramesh
 * Date: 23-12-2022
 */
//Data Transfering Objects 
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Patient {
	private long patientId;

	private String patientName;
	private String email;
	private long diagnosisId;
	private long consultantId;
}