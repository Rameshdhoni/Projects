package com.hcl.department;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DepartmentServiceApplicationTests {

	@Test
	void contextLoads() {
	}

	@Test
	void  doTest(){
		
		System.out.println("doTest");
	}

}
