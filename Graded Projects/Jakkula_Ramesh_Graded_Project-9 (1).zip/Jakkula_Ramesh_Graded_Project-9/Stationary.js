let stationaryItems=[
    {
        productname:"Note book",
         price : 20,
         Quantity:1
    },
    {
        productname:"Stapler",
        price : 50,
        Quantity:2

    },{

        productname:"Scissors",
        price : 50,
        Quantity:1
    },{
        productname:"Pens",
        price : 15,
        Quantity:1
    }

]
    let stationary=()=>{
        console.log(stationaryItems)
    }
    stationary();