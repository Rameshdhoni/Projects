package com.hcl.magicbook.ui;

import java.util.Scanner;

import com.hcl.magicbook.dao.BookDAOImp;
import com.hcl.magicbook.dao.IBookDAO;
import com.hcl.magicbook.dao.IuserDAO;
import com.hcl.magicbook.dao.UserDAOImp;
import com.hcl.magicbook.pojo.Book;
import com.hcl.magicbook.pojo.User;

public class MagicBook {
	IuserDAO dao = new UserDAOImp();

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("**** Welcome to MagicBook **** ");
		System.out.println("login here");
		System.out.println("enter username");
		String username = scanner.nextLine();
		System.out.println(" enter password");
		String password = scanner.nextLine();
		MagicBook mb = new MagicBook();

		boolean isuservalid = mb.validateUserLogin(username, password);
		if (isuservalid) {
			// menu
			System.out.println("Book menu");
			getBookMenu();
		} else {
			System.err.println("Invalid user credentials");
		}
	}

	public boolean validateUserLogin(String username, String password) {
		boolean isExist = false;
		User users[] = dao.getAllUser();

		for (User us : users) {
			if (us.getUserName().equals(username) && us.getPassword().equals(password)) {
				isExist = true;
			}
		}
		return isExist;
	}

	public static void getBookMenu() {
		IBookDAO bookdao = new BookDAOImp();
		System.out.println("**** WELCOME TO BOOK MENU ****");
		boolean flag = true;
		// IBook
		while (flag) {
			System.out.println("1. New Books");
			System.out.println("2. fav Books");
			System.out.println("3.completed Books");
			System.out.println("0 Exist");
			Scanner sc = new Scanner(System.in);
			int choice = sc.nextInt();
			switch (choice) {
			case 1:
				Book newBooks[] = bookdao.getAllBooks();
				System.out.println("i.show all new books");
				System.out.println("ii. get book by id");
				String key = sc.next();
				switch (key) {
				case "i":
					for (Book book : newBooks) {
						System.out.println(book);
					}
					break;
				case "ii":
					System.out.println("Enter Book Id");
					int id = sc.nextInt();
					for (Book book : newBooks) {
						if (book.getBookId() == id) {
							System.out.println(book);
						} // else
							// System.out.println(" sorry, book not avialble");
							// break;
					}
					break;
				default:
					break;
				}
				break;
			case 2:
				Book favbook[] = bookdao.getAllFavBooks();
				System.out.println("i.show all new books");
				System.out.println("ii. get book by id");
				String key1 = sc.next();
				switch (key1) {
				case "i":
					for (Book book : favbook) {
						System.out.println(book);
					}
					break;
				case "ii":
					System.out.println("Enter Book Id");
					int id = sc.nextInt();
					for (Book book : favbook) {
						if (book.getBookId() == id) {
							System.out.println(book);
						} // else
							// System.out.println(" sorry, book not avialble");
							// break;

					}
					break;
				default:
					break;
				}
				break;
			case 3:
				Book completedbook[] = bookdao.getAllCompletedBooks();
				System.out.println("i.show all new books");
				System.out.println("ii. get book by id");
				String key2 = sc.next();
				switch (key2) {
				case "i":
					for (Book book : completedbook) {
						System.out.println(book);
					}
					break;
				case "ii":
					System.out.println("Enter Book Id");
					int id = sc.nextInt();
					for (Book book : completedbook) {
						if (book.getBookId() == id) {
							System.out.println(book);
						} // else
							// System.out.println(" sorry, book not avialble");
							// break;

					}
					break;
				default:
					break;
				}
				break;
			case 0:
				flag = false;
				break;
			default:
				System.out.println("wrong choice and visit agin");
				break;

			}
		}
	}
}
