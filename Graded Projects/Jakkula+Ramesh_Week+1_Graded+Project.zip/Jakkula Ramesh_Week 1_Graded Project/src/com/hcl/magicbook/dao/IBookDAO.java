package com.hcl.magicbook.dao;

import com.hcl.magicbook.pojo.Book;

public interface IBookDAO {
	public abstract Book[] getAllBooks();

	public abstract Book[] getAllFavBooks();

	public abstract Book[] getAllCompletedBooks();

}
