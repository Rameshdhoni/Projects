package com.hcl.doctormicroservice.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.hcl.doctormicroservice.dto.Diagnosis;
import com.hcl.doctormicroservice.dto.DoctorDTO;
import com.hcl.doctormicroservice.dto.Patient;
import com.hcl.doctormicroservice.entity.Doctor;
import com.hcl.doctormicroservice.exception.DoctorNotFoundException;
import com.hcl.doctormicroservice.repository.DoctorRepository;
import com.hcl.doctormicroservice.vo.DoctorDiagnosisVO;
import com.hcl.doctormicroservice.vo.DoctorPatientVO;
/*
 * @Author: Ramesh
 * Date: 23-12-2022
 */
@Service
public class DoctorServiceImp implements IDoctorService {
	@Autowired
	DoctorRepository repo;
	@Autowired
	RestTemplate restTemplate;

	@Override
	// adding doctors into doctors table
	public Doctor addDoctors(DoctorDTO dto) {
		System.out.println(dto);
		Doctor doctor = new Doctor();
		doctor.setDoctorId(dto.getDoctorId());
		doctor.setDoctorName(dto.getDoctorName());
		doctor.setPatientId(dto.getPatientId());
		doctor.setDiagnosisId(dto.getDiagnosisId());
		System.out.println(doctor);
		return repo.save(doctor);
	}

	@Override
	// getting doctor details by using id
	public Doctor getById(long id) {
		try {
			return repo.findById(id).orElse(null);
		} catch (Exception e) {
			throw new DoctorNotFoundException();
		}
	}

	@Override
	// Displaying all doctor details
	public List<Doctor> getAll() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	@Override
	// getting diagnosis micro-service values using doctor microservice
	public DoctorDiagnosisVO getDoctorByIdWithDiagnosis(long doctorId) {
		try {
			Doctor doctor = getById(doctorId);
			long diagnosisId = doctor.getDiagnosisId();
			ResponseEntity<Diagnosis> response = restTemplate
					.getForEntity("http://localhost:8082/api/diagnosis/get/" + diagnosisId, Diagnosis.class);
			Diagnosis diagnosis = response.getBody();
			System.out.println(diagnosis);
			DoctorDiagnosisVO doctorDiagnosis = new DoctorDiagnosisVO(doctor, diagnosis);
			System.out.println(doctorDiagnosis);
			return doctorDiagnosis;
		} catch (Exception e) {
			throw new DoctorNotFoundException();
		}
	}

	@Override
	// getting patient micro-service values using doctor microservice
	public DoctorPatientVO getDoctorByIdWithPatient(long doctorId) {
		try {
			Doctor doctor = getById(doctorId);
			long patientId = doctor.getPatientId();
			// connecting one microservices to other micro services using rest template
			ResponseEntity<Patient> response = restTemplate
					.getForEntity("http://localhost:8081/api/patient/get/" + patientId, Patient.class);
			Patient patient = response.getBody();
			System.out.println(patient);
			DoctorPatientVO doctorPatient = new DoctorPatientVO(doctor, patient);
			System.out.println(doctorPatient);
			return doctorPatient;
		} catch (Exception e) {
			throw new DoctorNotFoundException();
		}
	}
}
