
let Grocery=[
    {
        productname:"Cheese",
         price : 45,
         Quantity:1
    },
    {
        productname:"Egg",
        price : 5,
        Quantity:2

    },{

        productname:"Oil",
        price : 100,
        Quantity:1
    },{
        productname:"Rice",
        price : 45,
        Quantity:1
    }

]
    let getList=()=>{
        console.log(Grocery)
    }
    getList();