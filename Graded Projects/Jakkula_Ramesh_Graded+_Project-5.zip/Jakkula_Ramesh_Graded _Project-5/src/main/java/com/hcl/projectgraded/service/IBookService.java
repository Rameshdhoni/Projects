package com.hcl.projectgraded.service;

import java.util.List;

import com.hcl.projectgraded.beans.Book;

public interface IBookService {
	public int addBook(Book book);

	public int updateBook(Book book);

	public int deleteBookById(int bid);

	public Book selectBookById(int bid);

	

	public List<Book> selectAll();


}
