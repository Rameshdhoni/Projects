package com.hcl.doctormicroservice.exception;
/*
 * @Author: Ramesh
 * Date: 23-12-2022
 */
public class DoctorNotFoundException extends RuntimeException {

	private String message;

	public DoctorNotFoundException(String message) {
		super(message);
		this.message = message;
	}

	public DoctorNotFoundException() {
	}
}
