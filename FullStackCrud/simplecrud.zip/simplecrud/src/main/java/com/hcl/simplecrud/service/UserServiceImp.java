package com.hcl.simplecrud.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.simplecrud.entity.User;
import com.hcl.simplecrud.exception.UserNotFoundException;
import com.hcl.simplecrud.repository.UserRepository;

@Service
public class UserServiceImp implements UserService {
	@Autowired
	UserRepository repo;

	@Override
	public User newUser(User newUser) {

		return repo.save(newUser);
	}

	@Override
	public List<User> getAllUsers() {

		return repo.findAll();
	}

	@Override
	public Optional<User> getUserById(Long id) {

		try {
			return repo.findById(id);
		} catch (Exception e) {
			throw new UserNotFoundException(id);
		}
	}

	@Override
	public User updateUser(User newUser,Long id) {
		return repo.findById(id)
                .map(user -> {
                    user.setUsername(newUser.getUsername());
                    user.setName(newUser.getName());
                    user.setEmail(newUser.getEmail());
                    return repo.save(user);
                }).orElseThrow(() -> new UserNotFoundException(id));
	}
		/*
		 * User user = repo.findById(newUser.getId()).orElse(null); if (user == null)
		 * throw new UserNotFoundException(newUser.getId()); else {
		 * user.setUsername(newUser.getUsername()); user.setName(newUser.getName());
		 * user.setEmail(newUser.getEmail()); return repo.save(user); }
		 * 
		 */	

	@Override
	public String deleteUser(Long id) {
		/*
		 * try { repo.deleteById(id); return "deleted sucussfully "; } catch (Exception
		 * e) { throw new UserNotFoundException(id); }
		 */
		if (!repo.existsById(id)) {
			throw new UserNotFoundException(id);
		}
		repo.deleteById(id);
		return "user with id " + id +"deleted sucussfully";
	}

}
