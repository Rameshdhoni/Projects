package com.hcl.diagnosismicroservice.exception;
/*
 * @Author: Ramesh
 * Date: 23-12-2022
 */
public class DiagnosisNotFoundException extends RuntimeException {

	private String message;

	public DiagnosisNotFoundException(String message) {
		super(message);
		this.message = message;
	}

	public DiagnosisNotFoundException() {
	}
}
