package com.hcl.magicbook.dao;

import java.util.List;

import com.hcl.magicbook.pojo.Book;

public interface IBookDAO {
	public abstract List<Book> getAllBooks();

	public abstract List<Book> getAllFavBooks();

	public abstract List<Book> getAllCompletedBooks();

}
