package com.hcl.doctormicroservice.dto;

import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
/*
 * @Author: Ramesh
 * Date: 23-12-2022
 */
//Data Transfering Objects 
@NoArgsConstructor
@AllArgsConstructor
@Data
public class DoctorDTO {
	private long doctorId;
	private String doctorName;
	private long patientId;
	private long diagnosisId;
}
