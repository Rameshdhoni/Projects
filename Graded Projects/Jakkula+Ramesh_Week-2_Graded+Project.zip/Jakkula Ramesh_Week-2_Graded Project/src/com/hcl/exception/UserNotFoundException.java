package com.hcl.exception;

public class UserNotFoundException extends Exception {

}
