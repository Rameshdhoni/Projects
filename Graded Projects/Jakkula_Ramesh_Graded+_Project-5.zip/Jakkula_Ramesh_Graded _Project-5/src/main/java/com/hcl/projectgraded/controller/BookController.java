package com.hcl.projectgraded.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.hcl.projectgraded.beans.Book;
import com.hcl.projectgraded.service.IBookService;

@Controller
@RequestMapping("/books")
public class BookController {
	@Autowired
	IBookService service;

	
	@RequestMapping("/AdminBookOperation")
	public String  WelcomeAdminpage () {

		return "AdminBookOperation";
	}
	
	@RequestMapping(value="/add",method=RequestMethod.POST)
	public String  addBook(Book book, HttpSession session) {

		int count =	service.addBook(book);



			session.setAttribute("status", count);

		return "display"; 

	}

	@RequestMapping(value="/update",method = RequestMethod.POST)
	public String   updateBook(Book book, HttpSession session) {


	int count =	service.updateBook(book);



		session.setAttribute("status", count);

				return "display";  // display.jsp page


			}

	@RequestMapping(value="/delete",method = RequestMethod.POST)
	public String   deleteBook(@RequestParam int bid, HttpSession session) {


	int count =	service.deleteBookById(bid);



		session.setAttribute("status", count);

				return "display";  // display.jsp page


			}

	@RequestMapping("/getall")
	public String  getAllProducts(HttpSession session) {

	List<Book> list =	service.selectAll();

	session.setAttribute("list", list);

		return "getAllBook";  
	}



}
