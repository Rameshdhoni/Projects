package com.hcl.gradedproject6.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hcl.gradedproject6.entities.FavouriteBook;
@Repository
public interface FavouriteBookRepository extends JpaRepository<FavouriteBook,Integer> {

}
