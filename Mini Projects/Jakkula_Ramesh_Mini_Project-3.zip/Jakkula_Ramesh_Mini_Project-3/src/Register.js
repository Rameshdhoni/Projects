import React from "react";
import {Outlet, Link} from "react-router-dom";
import './Register.css';
import { useNavigate } from "react-router-dom";
import { useState } from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import Navbar from 'react-bootstrap/Navbar';
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';

function Register() {

    var [na, changena] = useState("");
  var [em, changeem] = useState("");
  var [pa, changepa] = useState("");

  let nav = useNavigate();

  function handlesubmit(e) {
    na = na.trim();//trim is used to remove whitespaces from string(na=name,em=email,pa=password)
    em = em.trim();
    pa = pa.trim();
    var reg = /^\w+@\w+\.(com|org|net)$/;
    if (na.length === 0 || em.length === 0 || pa.length === 0) {
      alert("VALUE IS EMPTY ");
    } else if (!reg.test(em)) {
      alert("ENTER A PROPER EMAIL ID ");
    } else if (na.length < 5) {
        alert("NAME CAN'T BE LESS THAN 5");
     
    } else if (pa.length < 5) {
      alert("PASSWORD CAN'T BE LESS THAN 5");
    } else {
      e.preventDefault();
      localStorage.setItem("emid", em);
      fetch("http://localhost:3000/user", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: na,
          email: em,
          password: pa,
        }),
      })
        .then((res) => {
          res.text().then((resp2) => {
            alert("User Registered Successfully");
            nav("/Login");//or <Login></Login>
           
          });
        })
        .catch((err) => {
          console.log("error:", err);
        });
      
    }
  }
  //Onchage events 
  function onname(e) {
    changena(e.target.value);
  }
  function onemail(e) {
    changeem(e.target.value);
  }
  function onpass(e) {
    changepa(e.target.value);
  }

    return (
<>
            <div className="maindiv"    >
                <Navbar bg="light" expand="lg">
      
      <h3>Surabhi Restaurant</h3>
      
          <Nav className="me-auto">
            <Nav.Link href="/"></Nav.Link>
            <Nav.Link href="/Login">Login</Nav.Link>
            <Nav.Link href="/Register">Register</Nav.Link>
            <Nav.Link href="/">Logout</Nav.Link>

          </Nav>
      
      
    </Navbar>


                <div>
      <div className="box">
        <h1> SIGN UP </h1>
        <form>
          <div className="grp">
            <label htmlFor="name">Name:</label>
            <input
              type="text"
              name="name"
              id="name"
              placeholder="Enter Name"
              onChange={onname}
            />
          </div>
          <div className="grp">
            <label htmlFor="email">Email:</label>
            <input
              type="email"
              name="email"
              id="email"
              placeholder="Enter Email"
              onChange={onemail}
            />
          </div>

          <div className="grp">
            <label htmlFor="password">Password:</label>
            <input
              type="password"
              name="password"
              id="password"
              placeholder="Enter Password"
              onChange={onpass}
            />
          </div>
          <input type="submit" class="btn-submit" value="SIGN UP" onClick={handlesubmit}></input>
        </form>
      </div>
    </div>

           </div>
           </>
    );
    
}

export default Register;