package com.hcl.gradedproject6.entities;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;

@Entity
@Table(name = "Book_Table")
public class Book {
	@Id
	private int bookId;
	private String bookName;
	private String authourName;
	private int bookPrice;
	private String publicationName;

	public Book() {
		super();
	}

	public Book(int bookId, String bookName, String authourName, int bookPrice, String publicationName) {
		super();
		this.bookId = bookId;
		this.bookName = bookName;
		this.authourName = authourName;
		this.bookPrice = bookPrice;
		this.publicationName = publicationName;
	}

	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public String getAuthourName() {
		return authourName;
	}

	public void setAuthourName(String authourName) {
		this.authourName = authourName;
	}

	public int getBookPrice() {
		return bookPrice;
	}

	public void setBookPrice(int bookPrice) {
		this.bookPrice = bookPrice;
	}

	public String getPublicationName() {
		return publicationName;
	}

	public void setPublicationName(String publicationName) {
		this.publicationName = publicationName;
	}

	@Override
	public String toString() {
		return "Book [bookId=" + bookId + ", bookName=" + bookName + ", authourName=" + authourName + ", bookPrice="
				+ bookPrice + ", publicationName=" + publicationName + "]";
	}
}
