package com.hcl.projectgraded.dao;

import java.util.List;

import com.hcl.projectgraded.pojo.User;

public interface IUserDao {
	public int addUser(User user);

	public int updateUser(User user);

	public int deleteUserById(int userId);

	public User selectUserById(int userId);

	public List<User> selectAll();
}
