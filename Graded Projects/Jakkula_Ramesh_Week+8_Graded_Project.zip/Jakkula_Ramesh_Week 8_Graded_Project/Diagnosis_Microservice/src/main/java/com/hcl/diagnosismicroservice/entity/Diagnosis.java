package com.hcl.diagnosismicroservice.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
/*
 * @Author: Ramesh
 * Date: 23-12-2022
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
public class Diagnosis {
	@Id
	private long diagnosisId;
	@NotBlank
	private String diagnosisName;
	@Positive
	private long daignosisFee;
	@NotNull
	private long patientId;
}
