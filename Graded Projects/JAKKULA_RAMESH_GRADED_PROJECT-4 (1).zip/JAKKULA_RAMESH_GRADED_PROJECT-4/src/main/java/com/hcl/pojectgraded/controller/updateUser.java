package com.hcl.pojectgraded.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hcl.projectgraded.pojo.User;
import com.hcl.projectgraded.service.IUserService;
import com.hcl.projectgraded.service.IUserServiceImp;

/**
 * Servlet implementation class updateUser
 */
@WebServlet("/updateUser")
public class updateUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public updateUser() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		IUserService service=new IUserServiceImp();
		int id= Integer.parseInt(request.getParameter("userId"));//int 
		String userName=request.getParameter("userName");
		String email=request.getParameter("email");
		String address=request.getParameter("address");
		
		User user=new User(id,userName,email,address);
		int count= service.addUser(user);
		if(count>0) {
			out.print("User added sucussfully");
			out.print("<a href='WelcomeAdmin.jsp'> GO TO WELCOME ADMIN PAGE</a><br>");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
