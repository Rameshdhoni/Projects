package com.hcl.profilepageuser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserProfilePageApplicationTests {

	@Test
	void contextLoads() {
	}

}
