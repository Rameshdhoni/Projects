package com.hcl.gradedproject6.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.gradedproject6.entities.Admin;
import com.hcl.gradedproject6.entities.Book;
import com.hcl.gradedproject6.entities.FavouriteBook;
import com.hcl.gradedproject6.entities.User;
import com.hcl.gradedproject6.service.IUserService;

@RequestMapping("/api/user")
@RestController
public class UserController {

	@Autowired
	IUserService service;
	
	
	@PostMapping("/register")
	public ResponseEntity<String> registerUser(@RequestBody User user) {

		return service.registerUser(user);

	}
	@GetMapping("/login/{aName}/{password}")
	public ResponseEntity<String> login(@PathVariable String uname, @PathVariable String password,
			HttpSession session) {
		User use = service.findByuname(uname);
		ResponseEntity<String> response = null;
		if (use.getUname().equals(uname) && use.getPassword().equals(password)) {
			session.setAttribute("uname", uname);
			session.setAttribute("password", password);

			response = new ResponseEntity<String>("login done", HttpStatus.ACCEPTED);
		} else {
			response = new ResponseEntity<String>("login fail registration Failed", HttpStatus.BAD_REQUEST);
		}

		return response;

	}

	public String logout(HttpSession session) {
		session.invalidate();
		return "Logout Success";
	}
	
	@GetMapping("/findbyuname/{uname}")
	public User findByuname(@PathVariable String uname) {
		// TODO Auto-generated method stub
		return service.findByuname(uname);
	}
	@PostMapping("/add")
	public User addUser(@RequestBody User user) {
		
		return service.addUser(user);
	}

	@GetMapping("/getbyid/{bookId}")
	public Book searchBookById(@PathVariable int bookId) {
		return service.searchBookById(bookId);

	}

	@GetMapping("/getbyauthourname/{authourName}")
	public Book searchBookByAuthourName(@PathVariable String authourName) {
		// TODO Auto-generated method stub
		return service.searchBookByAuthourName(authourName);
	}

	@GetMapping("/getbybookname/{bookName}")
	public Book searchBookByBookName(@PathVariable String bookName) {
		// TODO Auto-generated method stub
		return service.searchBookByBookName(bookName);
	}

	@GetMapping("/getbypublicationname/{publicationName}")
	public Book searchBookByPublicationName(@PathVariable String publicationName) {

		return service.searchBookByPublicationName(publicationName);
	}

	@GetMapping("/getbypricerange/{low}/{high}")
	public List<Book> searchBookByPriceRange(@PathVariable int low, @PathVariable int high) {
		// TODO Auto-generated method stub
		return service.searchBookByPriceRange(low, high);
	}

	@GetMapping("/getAll")
	public List<Book> getAllBook() {

		return service.getAllBook();
	}

	@GetMapping("/sortbyprice")
	public List<Book> sortBookByPrice() {
		// TODO Auto-generated method stub
		return service.sortBookByPrice();
	}
	@PostMapping("/addFavbook")
	public FavouriteBook addFavouriteBook(@RequestBody FavouriteBook book) {
		// TODO Auto-generated method stub
		return service.addFavouriteBook(book);
		}
}
