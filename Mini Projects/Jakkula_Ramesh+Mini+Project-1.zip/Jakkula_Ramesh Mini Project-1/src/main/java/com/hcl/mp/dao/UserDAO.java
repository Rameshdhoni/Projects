package com.hcl.mp.dao;

import com.hcl.mp.pojo.Customer;

public interface UserDAO {
	
	public void showUserDetails();

	public void userRegister(Customer cus);

	public String isUserExistOrNot(String email, String password);

	public void removeUser(String email);

}
