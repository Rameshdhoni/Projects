package com.hcl.mp.exception;

public class CustomerNotFoundException extends Exception {

}
