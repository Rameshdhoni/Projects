package com.wipro.fms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FacultyRestApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
