package com.hcl.projectgraded.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;


import com.hcl.projectgraded.beans.User;
import com.hcl.projectgraded.service.IUserService;

@Controller
@RequestMapping("/users")
public class UserController {
@Autowired
	IUserService service;



@RequestMapping("/AdminUserOperations")
public String  WelcomeAdminpage () {

	return "AdminUserOperations";
}

@RequestMapping(value="/add",method=RequestMethod.POST)
public String  addUser(User user, HttpSession session) {

	int count =	service.addUser(user);



		session.setAttribute("status", count);

	return "display.jsp"; 

}

@RequestMapping(value="/update",method = RequestMethod.POST)
public String   updateUser(User user, HttpSession session) {


int count =	service.updateUser(user);



	session.setAttribute("status", count);

			return "display";  // display.jsp page


		}

@RequestMapping(value="/delete",method = RequestMethod.POST)
public String   deleteUser(@RequestParam int userId, HttpSession session) {


int count =	service.deleteUserById(userId);



	session.setAttribute("status", count);

			return "display";  // display.jsp page


		}

@RequestMapping("/getall")
public String  getAllProducts(HttpSession session) {

List<User> list =	service.selectAll();

session.setAttribute("list", list);

	return "getAllUser";  
}



}
