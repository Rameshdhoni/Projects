package com.hcl.doctormicroservice.service;

import java.util.List;

import com.hcl.doctormicroservice.dto.ConsultantDTO;
import com.hcl.doctormicroservice.entity.Consultant;
/*
 * @Author: Ramesh
 * Date: 23-12-2022
 */
public interface IConsultantService {
	// consultant CRUD operations
	public Consultant addConsultants(ConsultantDTO dto);

	public Consultant getById(long id);

	public List<Consultant> getAll();
}
