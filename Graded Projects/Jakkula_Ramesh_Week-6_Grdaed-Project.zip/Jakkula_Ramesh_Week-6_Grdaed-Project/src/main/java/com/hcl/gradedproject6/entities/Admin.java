package com.hcl.gradedproject6.entities;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;

@Entity
@Table(name = "Admin_Table")
public class Admin {
	@Id
	private int aId;
	private String aName;
	private String password;

	public Admin() {
		super();
	}

	public Admin(int aId, String aName, String password) {
		super();
		this.aId = aId;
		this.aName = aName;
		this.password = password;
	}

	public int getaId() {
		return aId;
	}

	public void setaId(int aId) {
		this.aId = aId;
	}

	public String getaName() {
		return aName;
	}

	public void setaName(String aName) {
		this.aName = aName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "Admin [aId=" + aId + ", aName=" + aName + ", password=" + password + "]";
	}
}
