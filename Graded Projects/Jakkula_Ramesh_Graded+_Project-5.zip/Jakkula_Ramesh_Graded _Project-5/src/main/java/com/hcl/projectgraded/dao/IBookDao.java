package com.hcl.projectgraded.dao;

import java.util.List;

import com.hcl.projectgraded.beans.Book;


public interface IBookDao {
	public int addBook(Book book);

	public int updateBook(Book book);

	public int deleteBookById(int bid);

	public Book selectBookById(int bid);

	public List<Book> selectAll();

}
