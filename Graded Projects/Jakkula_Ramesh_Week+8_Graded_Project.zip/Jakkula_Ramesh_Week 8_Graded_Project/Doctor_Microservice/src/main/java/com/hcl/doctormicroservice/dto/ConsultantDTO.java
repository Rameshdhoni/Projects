package com.hcl.doctormicroservice.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
/*
 * @Author: Ramesh
 * Date: 23-12-2022
 */
//Data Transfering Objects 
@AllArgsConstructor
@NoArgsConstructor
@Data
public class ConsultantDTO {
	private long consultantId;
	private long consulatntFee;
	private long doctorId;
}
