package com.hcl.diagnosismicroservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DiagnosisMicroserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(DiagnosisMicroserviceApplication.class, args);
	}

}
