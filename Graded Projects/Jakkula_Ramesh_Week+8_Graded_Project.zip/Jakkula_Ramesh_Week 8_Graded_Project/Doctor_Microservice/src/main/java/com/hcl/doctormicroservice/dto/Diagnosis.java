package com.hcl.doctormicroservice.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
/*
 * @Author: Ramesh
 * Date: 23-12-2022
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Diagnosis {
	// Data Transfering Objects
	private long diagnosisId;
	private String diagnosisName;
	private long daignosisFee;
	private long patientId;
}
