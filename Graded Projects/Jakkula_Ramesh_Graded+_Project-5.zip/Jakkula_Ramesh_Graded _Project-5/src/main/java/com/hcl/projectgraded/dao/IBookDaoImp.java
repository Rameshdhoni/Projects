package com.hcl.projectgraded.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.hcl.projectgraded.beans.Book;


@Repository
public class IBookDaoImp implements IBookDao {
	Connection conn = DBFactory.getDBConnection();
	PreparedStatement pstmt;
	
	@Override
	public int addBook(Book book) {
		String insertQuery = "insert into book values(?,?,?,?,?,?,?)";
		int count = 0;
		

		try {
			pstmt = conn.prepareStatement(insertQuery);
			pstmt.setInt(1, book.getBid());
			pstmt.setString(2, book.getBookName());
			pstmt.setString(3, book.getTypeOfBook());
			pstmt.setString(4, book.getGenreName());
			pstmt.setString(5, book.getDescrption());
			pstmt.setDouble(6, book.getBprice());
			pstmt.setInt(7, book.getNoOfCopiesSold());
			count = pstmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return count;
	}

	@Override
	public int updateBook(Book book) {
		// int i= book.getBid();
		String updateQuery = "update book set bookname = ? , typeOfBook = ? , genreName = ? , descrption = ? , bprice = ? , NoOfCopiesSold = ? where bid = ? ";
				int count = 0;
		try {
			pstmt = conn.prepareStatement(updateQuery);
			pstmt.setString(1, book.getBookName());
			pstmt.setString(2, book.getTypeOfBook());
			pstmt.setString(3, book.getGenreName());
			pstmt.setString(4, book.getDescrption());
			pstmt.setDouble(5, book.getBprice());
			pstmt.setInt(6, book.getNoOfCopiesSold());
			pstmt.setInt(7, book.getBid());
			count = pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return count;

	}

	@Override
	public int deleteBookById(int bid) {
		
		String deleteQuery = "delete from book where bid =?";
		int count = 0;
		try {
			pstmt = conn.prepareStatement(deleteQuery);
			pstmt.setInt(1, bid);

			count = pstmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return count;
	}

	@Override
	public Book selectBookById(int bid) {
		
		String selectOne = "select * from book where bid=?";
		int count = 0;
		Book book = new Book();
		try {
			pstmt = conn.prepareStatement(selectOne);
			pstmt.setInt(1, bid);

			// count = pstmt.executeUpdate();
			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				int bid1 = rs.getInt("bid");
				String bookname = rs.getString("bookname");
				String typeOfBook = rs.getString("typeofbook");
				String genreName = rs.getString("genreName");
				String descrption = rs.getString("descrption");
				double bprice = rs.getDouble("bprice");
				int NoOfCopiesSold = rs.getInt("NoOfCopiesSold");
				book.setBid(bid1);
				book.setBookName(bookname);
				book.setTypeOfBook(typeOfBook);
				book.setGenreName(genreName);
				book.setDescrption(descrption);
				book.setBprice(bprice);
				book.setNoOfCopiesSold(NoOfCopiesSold);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return book;
	}

	@Override
	public List<Book> selectAll() {
		List<Book> bookList = null;
		try {
			String selectQuery = "select * from book";
			pstmt = conn.prepareStatement(selectQuery);
			ResultSet rs = pstmt.executeQuery();
			bookList = new ArrayList<Book>();
			while (rs.next()) {
				int bid = rs.getInt("bid");
				String bookname = rs.getString("bookname");
				String typeOfBook = rs.getString("typeOfBook");
				String genreName = rs.getString("genreName");
				String descrption = rs.getString("descrption");
				double bprice = rs.getDouble("bprice");
				int NoOfCopiesSold = rs.getInt("NoOfCopiesSold");
				Book book = new Book();
				book.setBid(bid);
				book.setBookName(bookname);
				book.setTypeOfBook(typeOfBook);
				book.setGenreName(genreName);
				book.setDescrption(descrption);
				book.setBprice(bprice);
				book.setNoOfCopiesSold(NoOfCopiesSold);
				bookList.add(book);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return bookList;
	}
}
