package com.hcl.profilepageadmin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdminProfilePageApplicationTests {

	@Test
	void contextLoads() {
	}

}
