package com.hcl.mp.ui;

import java.util.Scanner;


import com.hcl.mp.dao.MenuDAO;
import com.hcl.mp.dao.MenuDAOImpl;
import com.hcl.mp.dao.UserDAO;
import com.hcl.mp.dao.UserDAOImpl;
import com.hcl.mp.exception.CustomerNotFoundException;
import com.hcl.mp.pojo.Customer;
import com.hcl.mp.pojo.FoodItem;
import com.hcl.mp.pojo.NonVegItem;
import com.hcl.mp.pojo.User;
import com.hcl.mp.pojo.VegItem;



public class RestaurantInfo {
	static MenuDAO md = MenuDAOImpl.getMenuDAOImpl();
	static UserDAO ud = UserDAOImpl.getUserDAO();
	static Scanner sc = new Scanner(System.in);
	public static final LogService LOGGER = new LogService();
	public static void main(String[] args) {
		
		Runnable r = new MythreadRunnable();
		Thread t = new Thread(r);
		t.start();
		boolean flag = true;
		while (flag) {
			LOGGER.log(" menu execution started ");
			System.out.println("*welcome to surabi restaurant*");
			System.out.println("Press 1 to REGISTER");
			System.out.println("Press 2 to LOGIN");
			System.out.println("Press 0 to EXIT");

			System.out.println();

			int option = sc.nextInt();

			switch (option) {
			case 1:
				System.out.println("Enter your Name : ");
				String name = sc.next();

				System.out.println("Enter your Email : ");
				String email = sc.next();

				System.out.println("Create your Password : ");
				String password = sc.next();

				User u = new User(name, email, password);
				Customer cus = new Customer(u);

				ud.userRegister(cus);
				break;

			case 2:

				System.out.println("Enter your Email : ");
				String email1 = sc.next();

				System.out.println("Enter your Password : ");
				String password1 = sc.next();

				String isLogin = ud.isUserExistOrNot(email1, password1);

				if (isLogin.equalsIgnoreCase("Admin")) {

					System.out.println("Admin Login");
					adminLogin();
					System.out.println();

				} else if (isLogin.equalsIgnoreCase("Customer")) {

					System.out.println("hey!....how can I help you..");
					customerLogin();
					System.out.println();

				}

				else {
					try {
						throw new CustomerNotFoundException();
					} catch (CustomerNotFoundException e) {
						System.err.println(" Sorry,Invalid User Credentials " + e);
						LOGGER.log(" User NotException Details ");
					}
				}
				break;
			case 0:
				System.out.println("Thank you...Bye");
				break;
			}

		}
	}

	private static void adminLogin() {

		while (true) {
			LOGGER.log(" Admin execution started ");
			System.out.println("Press 1 to ADD food items into the MENU\"");
			System.out.println("Press 2 to DELETE food items From the MENU");

			System.out.println("Press 3 to Update food items price into the MENU Based on NAME/ID");
			System.out.println("Press 4 to SEE all the Bills  generated Today");
			System.out.println("Press 5 to See the Total sale from this month");
			System.out.println("Press 6 To Remove Any Customer From the List");
			System.out.println("press 7 to display items");
			System.out.println("Press 0 to EXIT");
			int option = sc.nextInt();
			switch (option) {
			case 1:
				System.out.println("Enter Item Name : ");
				String name = sc.next();

				System.out.println("Set Price for " + name + " : ");
				int price = sc.nextInt();

				System.out
						.println("Press 'V' for set the item into Veg : \nPress 'NV' for set the item into Non-Veg :");
				String choice = sc.next();

				if (choice.equalsIgnoreCase("V")) {
					FoodItem fi = new FoodItem(name, price);
					VegItem v = new VegItem(choice, price, choice, fi);
					md.addFoodItems(fi, v.getCategory());
				} else if (choice.equalsIgnoreCase("NV")) {

					FoodItem fi = new FoodItem(name, price);
					NonVegItem nv = new NonVegItem(fi);
					md.addFoodItems(fi, nv.getCategory());
				} else {

					System.out.println("Choose veg or non-veg");
				}

				System.out.println("After Food-Item added Successfully!!!");

				md.showFoodItems();
				System.out.println();
				break;
			case 2:
				md.showFoodItems();
				System.out.println();
				System.out.println("Enter Food-Item ID to Delete from the Menu ");
				int id = sc.nextInt();
				md.deleteFoodItems(id);
				break;

			case 3:
				md.showFoodItems();
				System.out.println();
				System.out.println("Press A to UPDATE food-Item Price based On ID \n");
				System.out.println("Press B to UPDATE food-Item Price based On NAME");
				String ch = sc.next();

				if (ch.equalsIgnoreCase("A")) {
					System.out.println("Enter Food Item Id");
					int id1 = sc.nextInt();

					System.out.println("Enter NEW Price for the Food Item");
					int price1 = sc.nextInt();

					md.updateFoodItems(null, id1, price1);

				} else if (ch.equalsIgnoreCase("B")) {
					System.out.println("Enter Food Item Name");
					String name1 = sc.next();

					System.out.println("Enter NEW Price for the Food Item");
					int price1 = sc.nextInt();

					md.updateFoodItems(name1, 0, price1);

				}

				System.out.println();

				break;
			case 4:
				md.billsGeneratedToday();

			case 5:
				md.totalSale();
				break;
			case 6:
				System.out.println("enter user email delete");
				String email=sc.next();
				ud.removeUser(email);
				break;
				
			case 7:
				md.displayItems();
				break;
			case 0:
				System.out.println("Admin LOGOUT Successfully");
				break;

			default:
				System.out.println("Choose b/w 0-5");
				break;
			}

		}

	}

	private static void customerLogin() {

		while (true) {
			LOGGER.log(" customer execution started ");
			System.out.println("Press 1 to SEE all the Food-Items in the Menu");
			System.out.println("Press 2 to Order Your Food-Items");
			System.out.println("Press 3 to See the FINAL BILL");
			System.out.println("Press 0 to LogOut");

			int choice = sc.nextInt();

			switch (choice) {
			case 1:
				md.showFoodItems();
				break;
			case 2:
				md.orderItems();
				break;

			case 3:

				int bill = MenuDAOImpl.customerBill;
				System.out.println("Your BILL : " + bill);
				break;

			case 4:
				System.out.println("Thank You......Visit Again!!");
				md.emptyBill();
				break;
			case 0:
				System.out.println("customer LOGOUT Successfully");
				break;
			default:
				System.out.println("Choose b/w 0-3");
				break;
			}

		}
	}

}
