package com.hcl.patientmicroservice.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.patientmicroservice.dto.PatientDTO;
import com.hcl.patientmicroservice.entity.Patient;
import com.hcl.patientmicroservice.exception.PatientNotFoundException;
import com.hcl.patientmicroservice.repository.PatientRepository;

/*
 * @Author: Ramesh
 * Date: 23-12-2022
 */
@Service
public class PatientServiceImp implements IPatientService {
	@Autowired
	PatientRepository repo;

//patient crud operation like add
	@Override
	public Patient addPatient(PatientDTO dto) {
		Patient patient = new Patient();
		patient.setPatientId(dto.getPatientId());
		patient.setPatientName(dto.getPatientName());
		patient.setEmail(dto.getEmail());
		patient.setDiagnosisId(dto.getDiagnosisId());
		patient.setConsultantId(dto.getConsultantId());
		return repo.save(patient);
	}

//getting patient details by using id
	@Override
	public Patient getById(long id) {
		try {
			return repo.findById(id).orElse(null);
		} catch (Exception e) {
			throw new PatientNotFoundException();
		}
	}

//getting all patient details
	@Override
	public List<Patient> getAll() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

}
