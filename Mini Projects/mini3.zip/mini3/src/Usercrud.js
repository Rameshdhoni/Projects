import axios from "axios";
import React, { useState } from 'react';
import { useEffect } from 'react';
import Navbar from 'react-bootstrap/Navbar';
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Table from 'react-bootstrap/Table';
import Button from 'react-bootstrap/Button';
import './Menucrud.css';
import 'bootstrap/dist/css/bootstrap.min.css';





function Usercrud(){

    //array
    var[post, setPost] = useState([]);

    var[newTitle, setNewTitle]= useState();
    var[newAuthor, setNewAuthor]=useState();
    var[newPass, setNewPass]=useState();

    //updatinfg data
    var[oldTitle, setoldTitle]= useState();
    var[oldAuthor, setoldAuthor]=useState();
    var[oldPass, setoldPass]=useState();
    var[oldId, setoldId] = useState();
//for deleteing
    var[deleteId, setdeleteId] = useState();

    
   




    function loadPostfromServer(){
        axios.get("http://localhost:3000/user").then((response) => {

        setPost(response.data);
        
     } )
    }
    

    useEffect(loadPostfromServer, []);
    function addData(event){
        event.preventDefault();
        const newPost = {
            name: newTitle,
            email: newAuthor,
            password: newPass
           
        };
        axios.post("http://localhost:3000/user",newPost).then((res)=>{
            loadPostfromServer();
        })
    

    }
    function updateData(event){
        event.preventDefault();
        const oldPost = {
            name: oldTitle,
            email: oldAuthor,
            id : oldId,
            password: oldPass

           


        };
        axios.put("http://localhost:3000/user/"+oldId,oldPost).then((res)=>{
            loadPostfromServer();



        })
    }

    function deleteData(event){
        event.preventDefault();
        axios.delete("http://localhost:3000/user/"+deleteId).then((res)=>{
            loadPostfromServer();
    })
    }

    return(


        <div>
            <Navbar bg="light" expand="lg">
        
          <Navbar.Brand href="#home">Surabhi Restaurant</Navbar.Brand>
          <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav">
            <Nav className="me-auto">
              <Nav.Link href="/Ahome">Home</Nav.Link>
              <Nav.Link href="/">Logout</Nav.Link>
  
            </Nav>
          </Navbar.Collapse>
        
      </Navbar>

    <Container>
        <Button variant="primary" href="#user">Add New User</Button>
      <Table striped bordered hover style={{margin:'20px'}}>
      <thead>
        <tr>
          <th>Sl No.</th>
          <th>User</th>
          <th>Email</th>
        </tr>
      </thead>
      <tbody>
                    {
                        post.map(temp => {
                            return(
                                <tr>
                                    <td>{temp.id}</td>
                                    <td>{temp.name}</td>
                                    <td>{temp.email}</td>
                                    <td><Button variant="primary" href="#update">Edit</Button></td>
                                    <td><Button variant="danger" href="#delete" onClick="">Delete</Button></td>
                                </tr>
                            )
                        })
                    }


                </tbody>
    </Table>
    </Container>

            <hr></hr>
            
            <div id="user">
            <h1>Add User</h1>
            <form onSubmit={addData}>
                <label>User :</label>
                <input type="text"required  onChange={e=>setNewTitle(e.target.value)}/>
                <br></br>
                <label>Email :</label>
                <input type="text" required  onChange={e=>setNewAuthor(e.target.value)}/>
                <br></br>
                <label>Password :</label>
                <input type="text" required  onChange={e=>setNewPass(e.target.value)}/>
                <br></br>
                <button type="submit">Add Data</button>
            </form>
            </div>


            <hr></hr>
            <div id="update">
            <h1>Edit User</h1>
            <form onSubmit={updateData}>
            <label>ID :</label>
                <input type="number" onChange={e=>setoldId(e.target.value)}/>
                <br></br>

                <label>User :</label>
                <input type="text" required value={oldTitle} onChange={e=>setoldTitle(e.target.value)}/>
                <br></br>
                <label>Email :</label>
                <input type="text" required value={oldAuthor} onChange={e=>setoldAuthor(e.target.value)}/>
                <br></br>
                <label>Password :</label>
                <input type="text" required value={oldPass} onChange={e=>setoldPass(e.target.value)}/>
                <br></br>
                <button type="submit">Update Data</button>
            </form>
            </div>

            <hr></hr>
            
            <div id="delete">
            <h1>Delete User</h1>
            <form onSubmit={deleteData}>
            <label>ID data u want to delete :</label>
                <input type="number" required onChange={e=>setdeleteId(e.target.value)}/>
                <br></br>
                <button type="submit">Delete Data</button>
                </form>
                </div>
        </div>
    )


}
export default Usercrud;