package com.hcl.gradedproject6.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.hibernate.annotations.common.util.impl.LoggerFactory;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.gradedproject6.entities.Admin;
import com.hcl.gradedproject6.entities.Book;
import com.hcl.gradedproject6.service.IAdminService;

@RequestMapping("/api/admin")
@RestController
public class AdminController {

	@Autowired
	IAdminService service;

	@PostMapping("/register")
	public ResponseEntity<String> registerAdmin(@RequestBody Admin admin) {

		return service.registerAdmin(admin);

	}

	@GetMapping("/login/{aName}/{password}")
	public ResponseEntity<String> login(@PathVariable String aName, @PathVariable String password,
			HttpSession session) {
		Admin admi = service.findByaName(aName);
		ResponseEntity<String> response = null;
		if (admi.getaName().equals(aName) && admi.getPassword().equals(password)) {
			session.setAttribute("aName", aName);
			session.setAttribute("password", password);

			response = new ResponseEntity<String>("login done", HttpStatus.ACCEPTED);
		} else {
			response = new ResponseEntity<String>("login fail registration Failed", HttpStatus.BAD_REQUEST);
		}

		return response;

	}

	public String logout(HttpSession session) {
		session.invalidate();
		return "Logout Success";
	}
	@GetMapping("/get/{aName}/{password}")
	public Admin findByaName(@PathVariable String aName) {
		// TODO Auto-generated method stub
		return service.findByaName(aName);
	}
	@PostMapping("/insert")
	public Book insertBook(@RequestBody Book book) {
		// TODO Auto-generated method stub

		return service.insertBook(book);
	}

	@PutMapping("/update")
	public Book updateBook(@RequestBody Book book) {
		// TODO Auto-generated method stub
		return service.updateBook(book);
	}

	@DeleteMapping("/remove/{bookId}")
	public String removeBook(@PathVariable int bookId) {

		return service.removeBook(bookId);

	}

	@GetMapping("/getAll")
	public List<Book> getAllBook() {
		// TODO Auto-generated method stub
		return service.getAllBook();
	}

	@GetMapping("/get/{bookId}")
	public Book searchBookById(@PathVariable int bookId) {
		// TODO Auto-generated method stub
		return service.searchBookById(bookId);
	}

	@GetMapping("/get/{authourName}")
	public Book searchBookByAuthourName(@PathVariable String authourName) {
		// TODO Auto-generated method stub
		return service.searchBookByAuthourName(authourName);
	}

}
