package com.hcl.projectgraded.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.projectgraded.beans.Book;
import com.hcl.projectgraded.dao.IBookDaoImp;


@Service
public class IBookServiceImp implements IBookService {
@Autowired
	IBookDaoImp dao;

	public IBookServiceImp() {
		
	}

	@Override
	public int addBook(Book book) {
		// TODO Auto-generated method stub
		return dao.addBook(book);
	}

	@Override
	public int updateBook(Book book) {
		// TODO Auto-generated method stub
		return dao.updateBook(book);
	}

	@Override
	public int deleteBookById(int bid) {
		// TODO Auto-generated method stub
		return dao.deleteBookById(bid);
	}

	@Override
	public Book selectBookById(int bid) {
		// TODO Auto-generated method stub
		return dao.selectBookById(bid);
	}

	@Override
	public List<Book> selectAll() {
		// TODO Auto-generated method stub
		return dao.selectAll();
	}


}
