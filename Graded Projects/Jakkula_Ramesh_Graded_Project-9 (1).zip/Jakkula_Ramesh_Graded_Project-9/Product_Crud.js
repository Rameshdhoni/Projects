function getById(){
    fetch("http://localhost:3000/CartItems/1")
    .then(response=>{return response.json()})
    .then(emplist=>{console.log(emplist);
    document.getElementById("demo").innerHTML=JSON.stringify(emplist);
});
}

function getAll(){
    fetch("http://localhost:3000/CartItems")
    .then(response=>{return response.json()})
    .then(emplist=>{console.log(emplist);
    document.getElementById("demo").innerHTML=JSON.stringify(emplist);
});
}
function add(){
    fetch("http://localhost:3000/CartItems",
    {
        method: 'POST',
        body: JSON.stringify({
            "id": 5,
            "productName": "oils",
            "Category": "grocery",
            "Description": "use in cooking",
            "Quantity" : 2
        }),
        headers: {
            "Content-Type": 'application/json'
        }
    })
    .then(res=>{ return res.json()})
    .then(data =>{ console.log(data);
    document.getElementById("demo").innerHTML=JSON.stringify(data);
});
}

function deleteProduct(){
    fetch("http://localhost:3000/CartItems/5",
    {
        method: 'DELETE',
        
        headers: {
            "Content-Type": 'application/json'
        }
    })
    .then(res=> console.log(res.status));
    
}