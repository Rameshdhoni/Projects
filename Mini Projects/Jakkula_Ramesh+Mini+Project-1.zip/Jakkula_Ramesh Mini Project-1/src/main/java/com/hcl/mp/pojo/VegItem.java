package com.hcl.mp.pojo;

public class VegItem extends FoodItem {
	private String category = "Veg";

	private FoodItem foodItem;

	public VegItem(String itemName, int price, String category, FoodItem foodItem) {
		super(itemName, price);
		this.category = category;
		this.foodItem = foodItem;
	}

	public int getId() {
		return foodItem.getId();
	}

	public void setId(int id) {
		this.setId(id);
	}

	public String getCategory() {
		return category;
	}

	public String getItemName() {
		return foodItem.getItemName();
	}

	public void setItemName(String itemName) {
		this.setItemName(itemName);
	}

	public int getPrice() {
		return foodItem.getPrice();
	}

	public void setPrice(int price) {
		this.setPrice(price);
	}

	@Override
	public String toString() {
		return "Veg [foodItem=" + foodItem + "]";
	}

}
