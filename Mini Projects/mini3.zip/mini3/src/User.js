import React from "react";
import {Link, NavLink} from "react-router-dom";
import './User.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Navbar from 'react-bootstrap/Navbar';
import Nav from 'react-bootstrap/Nav';


function User() {

    return(
      <>
        <Navbar bg="light" expand="lg">
      <h1>User Operation</h1>
          <Nav className="me-auto">
            <Nav.Link href="/"></Nav.Link>
            <Nav.Link href="/Login">Login</Nav.Link> {/* we can also use like this <NavLink to="/Login">Loginnn</NavLink> */}
            <Nav.Link href="/Register">Register</Nav.Link>
            <Nav.Link href="/">Logout</Nav.Link>

          </Nav>
    </Navbar>
    </>
    );
}

export default User;