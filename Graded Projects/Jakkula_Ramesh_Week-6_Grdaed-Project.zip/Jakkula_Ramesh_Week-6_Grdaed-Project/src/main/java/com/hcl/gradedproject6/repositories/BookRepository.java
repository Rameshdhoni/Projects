package com.hcl.gradedproject6.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.hcl.gradedproject6.entities.Book;

@Repository
public interface BookRepository extends JpaRepository<Book, Integer> {

	Book searchBookByAuthourName(String authourName);

	Book searchBookByBookName(String bookName);

	Book searchBookByPublicationName(String publicationName); //

	@Query("select b from Book b order by bookPrice desc ")
	List<Book> sortBookByPrice();

	@Query("select b from Book b where  bookPrice  between ?1 and ?2 order by bookId asc ")
	List<Book> searchBookByPriceRange(int low, int high);
}
