package com.hcl.diagnosismicroservice.restcontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.diagnosismicroservice.dto.DiagnosisDTO;
import com.hcl.diagnosismicroservice.entity.Diagnosis;
import com.hcl.diagnosismicroservice.service.IDiagnosisService;
/*
 * @Author: Ramesh
 * Date: 23-12-2022
 */
@RestController
@RequestMapping("/api/diagnosis")
public class DiagnosisController {

	@Autowired
	IDiagnosisService service;
// Diagnosis crud operations and taking input from user using postman,soap-ui or swagger
	@PostMapping("/adddiagnosis")
	public Diagnosis add(@RequestBody DiagnosisDTO dto) {
		return service.add(dto);
	}
//getting particular Diagnosis details using id 
	@GetMapping("/get/{id}")
	public Diagnosis get(@PathVariable long id) {
		return service.get(id);
	}
	//getting all Diagnosis details 
	@GetMapping("/getAll")
	public List<Diagnosis> getall() {
		return service.getall();

	}
}