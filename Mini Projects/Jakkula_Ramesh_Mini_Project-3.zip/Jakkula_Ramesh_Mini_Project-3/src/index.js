import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
//import App from './App';
import { BrowserRouter,Routes, Route } from 'react-router-dom';
import Mainpage from './Mainpage';
 import Login from './Login';
 import Register from './Register';
import Products from './Products';
import User from './User';
import Admin from './Admin';
import UserMenu from './UserMenu';
import Alogin from './Alogin';
import Ahome from './Ahome';
import MenuCrud from './Menucrud';
import Usercrud from './Usercrud';
import Today from './Today';
import MonthlySale from './MonthlySale';



const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <BrowserRouter>
    <Routes>
    
      <Route path='/' element={<Mainpage></Mainpage>} ></Route>
      <Route path='/login' element={<Login></Login>}></Route>
      <Route path='/register' element={<Register></Register>}></Route>
      <Route path='/products' element={<Products></Products>}></Route>
      <Route path='/user' element={<User></User>}></Route>
      <Route path='/admin' element={<Admin></Admin>}></Route>
      <Route path='/usermenu' element={<UserMenu></UserMenu>}></Route>
      <Route path='/alogin' element={<Alogin></Alogin>}></Route>
      <Route path='/ahome' element={<Ahome></Ahome>}></Route>
      <Route path='/menucrud' element={<MenuCrud></MenuCrud>}></Route>
      <Route path='/usercrud' element={<Usercrud></Usercrud>}></Route>
      <Route path='/Today' element={<Today></Today>}></Route>
      <Route path='/MonthlySale' element={<MonthlySale></MonthlySale>}></Route>

    
  </Routes>
  </BrowserRouter>

  
);