package com.hcl.magicbook.pojo;

import com.hcl.service.LogService;

public class Book {
	private String bookName;
	private String authorName;
	private String description;
	private int bookId;
	public static final LogService LOGGER = new LogService();

	public Book() {
		super();
	}

	public Book(String bookName, String authorName, String description, int bookId) {
		super();
		this.bookName = bookName;
		this.authorName = authorName;
		this.description = description;
		this.bookId = bookId;
		LOGGER.log(" Initializing instance variable ");

	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public String getAuthorName() {
		return authorName;
	}

	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	@Override
	public String toString() {
		return "Book [bookName=" + bookName + ", authorName=" + authorName + ", description=" + description
				+ ", bookId=" + bookId + "]";
	}
}
