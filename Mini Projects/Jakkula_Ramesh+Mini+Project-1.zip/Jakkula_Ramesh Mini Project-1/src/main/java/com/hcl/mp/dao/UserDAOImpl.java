package com.hcl.mp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.hcl.mp.db.DBConnection;
import com.hcl.mp.pojo.Admin;
import com.hcl.mp.pojo.Customer;
import com.hcl.mp.pojo.User;
import com.hcl.mp.ui.LogService;

public class UserDAOImpl implements UserDAO{
	public static final LogService LOGGER = new LogService();
private static UserDAO userDAOImpl;
	
	//singleton pattern
	private UserDAOImpl() {
		
	}
	
	public static UserDAO getUserDAO() {
		if (userDAOImpl == null) {
			userDAOImpl = new UserDAOImpl();

		}
		return userDAOImpl;
	}

	@Override
	public void showUserDetails() {
		// TODO Auto-generated method stub
		LOGGER.log(" showdetails method started ");
		try {

			Connection a = DBConnection.getConnection();

			//Step3-Write SQL queries
			String s = "SELECT * FROM user_details ORDER BY u_type";

			//Step4-Get a carrier
			PreparedStatement ps = a.prepareStatement(s);
			

			//Step5-Execute the queries
			ResultSet result = ps.executeQuery();
			while (result.next()) {

				String name = result.getString("u_name");
				String email = result.getString("email");
				String password = result.getString("u_password");
				String type = result.getString("u_type");
				
				if(type.equalsIgnoreCase("Admin")) {
					User u = new User(name, email, password);
					Admin admin = new Admin(u);
					System.out.println(admin);
				}
				else if(type.equalsIgnoreCase("Customer")) {
					User u = new User(name, email, password);
					Customer customer = new Customer(u);
					System.out.println(customer);
				}
					
				
				
			}

			// Step#6. Close the resources
			//ps.close();
			//a.close();
		} catch (SQLException e) {
			System.out.println(e);
		}

		System.out.println("\n");
		
	}

	@Override
	public void userRegister(Customer customer) {
		// TODO Auto-generated method stub
		LOGGER.log("user registrition excution method started ");
		try {

			Connection a = DBConnection.getConnection();

			// Step#3. Write SQL queries
			String s = "INSERT INTO user_details VALUES(? , ? , ? , ?)";

			// Step#4. Get a carrier
			PreparedStatement ps = a.prepareStatement(s);
			ps.setString(1, customer.getName());
			ps.setString(2, customer.getEmail());
			ps.setString(3, customer.getPassword());
			ps.setString(4, customer.getUserType());

			// Step#5. Execute the queries
			ps.executeUpdate();
			// Step#6. Close the resources
			//ps.close();
			//a.close();
		} catch (SQLException e) {
			System.out.println(e);
		}

		
		System.out.println("registed suscussfully");
		
	}

	@Override
	public String isUserExistOrNot(String email, String password) {
		// TODO Auto-generated method stub
		String str = "";
		try {


			Connection a = DBConnection.getConnection();

			// Step#3. Write SQL queries
			String s = "SELECT u_password ,u_type FROM user_details WHERE email = ?";

			// Step#4. Get a carrier
			PreparedStatement ps = a.prepareStatement(s);
			ps.setString(1, email);

			// Step#5. Execute the queries
			ResultSet result = ps.executeQuery();
			while (result.next()) {
				String pass = result.getString("u_password");
				String type = result.getString("u_type");
				if(pass.equals(password)) {
					System.out.println("********** User Login Is successful **********");
					str = type;
					
				}else {
					str = null;
				}
			}
			// Step#6. Close the resources
			//ps.close();
			//a.close();
		} catch (SQLException e) {
			System.out.println(e);
		}
		System.out.println();
		return str;
	}

	@Override
	public void removeUser(String email) {
		// TODO Auto-generated method stub
		LOGGER.log(" removing excution  method started ");
		try {

			Connection c = DBConnection.getConnection();

			// Step#3. Write SQL queries
			String s = "DELETE FROM user_details WHERE email = ?";

			// Step#4. Get a carrier
			PreparedStatement ps = c.prepareStatement(s);
			ps.setString(1, email);
			// Step#5. Execute the queries
			ps.executeUpdate();
			// Step#6. Close the resources
			System.out.println("Customer Whose email : "+email+" removed from the List");
			//ps.close();
			//c.close();
		} catch (SQLException e) {
			System.out.println(e);
		}

		
		System.out.println();
		
	}
		
	}


