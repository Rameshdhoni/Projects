package com.hcl.magicbook.dao;

import java.util.List;

import com.hcl.magicbook.pojo.User;

public interface IuserDAO {
	public abstract List<User> getAllUser();
}
