package com.hcl.projectgraded.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.hcl.projectgraded.pojo.Book;
import com.hcl.projectgraded.presentation.LogService;


public class IBookDaoImp implements IBookDao {
	Connection conn = DBFactory.getDBConnection();
	PreparedStatement pstmt;
	public static final LogService LOGGER = new LogService();

	@Override
	public int addBook(Book book) {
		String insertQuery = "insert into book values(?,?,?,?,?,?,?)";
		int count = 0;
		LOGGER.log(" adding book using querys ");

		try {
			pstmt = conn.prepareStatement(insertQuery);
			pstmt.setInt(1, book.getBid());
			pstmt.setString(2, book.getBookName());
			pstmt.setString(3, book.getTypeOfBook());
			pstmt.setString(4, book.getGenreName());
			pstmt.setString(5, book.getDescrption());
			pstmt.setDouble(6, book.getBprice());
			pstmt.setInt(7, book.getNoOfCopiesSold());
			count = pstmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return count;
	}

	@Override
	public int updateBook(Book book) {
		// int i= book.getBid();
		String updateQuery = "update book set bookname = ? , typeOfBook = ? , genreName = ? , descrption = ? , bprice = ? , NoOfCopiesSold = ? where bid = ? ";
		LOGGER.log(" updating book using querys ");
		int count = 0;
		try {
			pstmt = conn.prepareStatement(updateQuery);
			pstmt.setString(1, book.getBookName());
			pstmt.setString(2, book.getTypeOfBook());
			pstmt.setString(3, book.getGenreName());
			pstmt.setString(4, book.getDescrption());
			pstmt.setDouble(5, book.getBprice());
			pstmt.setInt(6, book.getNoOfCopiesSold());
			pstmt.setInt(7, book.getBid());
			count = pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return count;

	}

	@Override
	public int deleteBookById(int bid) {
		LOGGER.log(" deleting book using querys ");
		String deleteQuery = "delete from book where bid =?";
		int count = 0;
		try {
			pstmt = conn.prepareStatement(deleteQuery);
			pstmt.setInt(1, bid);

			count = pstmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return count;
	}

	@Override
	public Book selectBookById(int bid) {
		LOGGER.log(" selecting book using querys ");
		String selectOne = "select * from book where bid=?";
		int count = 0;
		Book book = new Book();
		try {
			pstmt = conn.prepareStatement(selectOne);
			pstmt.setInt(1, bid);

			// count = pstmt.executeUpdate();
			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				int bid1 = rs.getInt("bid");
				String bookname = rs.getString("bookname");
				String typeOfBook = rs.getString("typeofbook");
				String genreName = rs.getString("genreName");
				String descrption = rs.getString("descrption");
				double bprice = rs.getDouble("bprice");
				int NoOfCopiesSold = rs.getInt("NoOfCopiesSold");
				book.setBid(bid1);
				book.setBookName(bookname);
				book.setTypeOfBook(typeOfBook);
				book.setGenreName(genreName);
				book.setDescrption(descrption);
				book.setBprice(bprice);
				book.setNoOfCopiesSold(NoOfCopiesSold);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return book;
	}

	@Override
	public List<Book> selectAll() {
		List<Book> bookList = null;
		try {
			String selectQuery = "select * from book";
			pstmt = conn.prepareStatement(selectQuery);
			ResultSet rs = pstmt.executeQuery();
			bookList = new ArrayList<Book>();
			while (rs.next()) {
				int bid = rs.getInt("bid");
				String bookname = rs.getString("bookname");
				String typeOfBook = rs.getString("typeOfBook");
				String genreName = rs.getString("genreName");
				String descrption = rs.getString("descrption");
				double bprice = rs.getDouble("bprice");
				int NoOfCopiesSold = rs.getInt("NoOfCopiesSold");
				Book book = new Book();
				book.setBid(bid);
				book.setBookName(bookname);
				book.setTypeOfBook(typeOfBook);
				book.setGenreName(genreName);
				book.setDescrption(descrption);
				book.setBprice(bprice);
				book.setNoOfCopiesSold(NoOfCopiesSold);
				bookList.add(book);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return bookList;
	}

	@Override
	public void highToLow() {
		String selectOne1 = "select * from book ORDER by bprice desc ";
		int count = 0;
		Book book = new Book();
		try {

			Statement stmt = conn.createStatement();

			ResultSet rs = stmt.executeQuery(selectOne1);

			while (rs.next()) {

				int bid = rs.getInt("bid");
				String bookName = rs.getString("bookName");
				String typeOfBook = rs.getString("typeofbook");
				String genreName = rs.getString("genreName");
				String descrption = rs.getString("descrption");
				double bprice = rs.getDouble("bprice");
				int NoOfCopiesSold = rs.getInt("NoOfCopiesSold");
				System.out.println(bid + "   " + bookName + "   " + typeOfBook + "   " + genreName + "   " + descrption
						+ "   " + bprice + "   " + NoOfCopiesSold);
				/*
				 * book.setBid(bid1); book.setBookName(bookName);
				 * book.setTypeOfBook(typeOfBook); book.setGenreName(genreName);
				 * book.setDescrption(descrption); book.setBprice(bprice1);
				 */

			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	@Override
	public void lowToHigh() {
		String selectOne = "select * from book ORDER BY bprice ";
		int count = 0;
		Book book = new Book();
		try {

			Statement stmt = conn.createStatement();

			ResultSet rs = stmt.executeQuery(selectOne);

			while (rs.next()) {

				int bid = rs.getInt("bid");
				String bookName = rs.getString("bookName");
				String typeOfBook = rs.getString("typeofbook");
				String genreName = rs.getString("genreName");
				String descrption = rs.getString("descrption");
				double bprice = rs.getDouble("bprice");
				int NoOfCopiesSold = rs.getInt("NoOfCopiesSold");
				System.out.println(bid + "   " + bookName + "   " + typeOfBook + "   " + genreName + "   " + descrption
						+ "   " + bprice + "   " + NoOfCopiesSold);

				/*
				 * book.setBid(bid1); book.setBookName(bookName);
				 * book.setTypeOfBook(typeOfBook); book.setGenreName(genreName);
				 * book.setDescrption(descrption); book.setBprice(bprice1);
				 */
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	@Override
	public void bestSelling() {

		String selectOne = "select MAX( NoOfCopiesSold) AS Bestselling from book ";
		int count = 0;
		Book book = new Book();
		try {

			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(selectOne);
			if (rs.next()) {

				int NoOfCopiesSold = rs.getInt("Bestselling");

				System.out.println("the book sold highest number of times is : " + NoOfCopiesSold);

			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void autoBioGraphy() {
		String selectOne = "select * from book where genreName= 'autobiography' ";
		int count = 0;
		Book book = new Book();
		try {

			Statement stmt = conn.createStatement();

			ResultSet rs = stmt.executeQuery(selectOne);

			while (rs.next()) {

				int bid = rs.getInt("bid");
				String bookName = rs.getString("bookName");
				String typeOfBook = rs.getString("typeofbook");
				String genreName = rs.getString("genreName");
				String descrption = rs.getString("descrption");
				double bprice = rs.getDouble("bprice");
				int NoOfCopiesSold = rs.getInt("NoOfCopiesSold");
				System.out.println(bid + "   " + bookName + "   " + typeOfBook + "   " + genreName + "   " + descrption
						+ "   " + bprice + "   " + NoOfCopiesSold);

				System.out.println(" ");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

}