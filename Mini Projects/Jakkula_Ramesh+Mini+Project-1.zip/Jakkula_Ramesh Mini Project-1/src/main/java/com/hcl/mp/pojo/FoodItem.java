package com.hcl.mp.pojo;

public class FoodItem {
	private int id;
	private String itemName;
	private int price;
	
	public FoodItem(String itemName, int price) {
		super();
		this.itemName = itemName;
		this.price = price;
	}

	public FoodItem(int id, String itemName, int price) {
		super();
		this.id = id;
		this.itemName = itemName;
		this.price = price;
	}
	
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}

	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "FoodItem [id=" + id + ", itemName=" + itemName + ", price=" + price + "]";
	}

}
