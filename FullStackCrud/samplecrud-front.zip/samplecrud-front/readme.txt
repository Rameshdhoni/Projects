using functional and axios did crud operations
1)npx install create-react-app samplecrud-front
2)npm i bootstrap
3)npm i axios
4)npm i react-router-dom
 
useState ,useEffect ---> hooks used
Router--> for navigations

backend

dependencies added :

 mysql driver, spring web, spring data jpa, dev tools,lombok, swagger open api, spring validations ,actucator