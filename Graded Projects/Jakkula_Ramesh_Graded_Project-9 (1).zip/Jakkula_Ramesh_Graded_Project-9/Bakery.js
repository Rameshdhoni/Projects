let bakeryItems=[
    {
        productname:"Egg puffs",
         price : 20,
         Quantity:1
    },
    {
        productname:"Ice Cream Vennela",
        price : 50,
        Quantity:2

    },{

        productname:"chicken rolls",
        price : 100,
        Quantity:1
    },{
        productname:"Cool drinks",
        price : 45,
        Quantity:1
    }

]
    let bakery=()=>{
        console.log(bakeryItems)
    }
    bakery();